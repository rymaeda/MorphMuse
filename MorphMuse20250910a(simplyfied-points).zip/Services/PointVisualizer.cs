﻿using CamBam.CAD;
using CamBam.UI;
using CamBam.Geom;
using System.Collections.Generic;

public static class PointVisualizer
{
    private static CamBamUI _ui = CamBamUI.MainUI;

    public static void VisualizePointsOnly(List<List<Point3F>> sampledCurves, string layerName, double markerRadius, int maxPoints)
    {
        CADFile cadFile = _ui.ActiveView.CADFile;

        // Cria camada única se ainda não existir
        if (!cadFile.HasLayer(layerName))
        {
            cadFile.CreateLayer(layerName);
        }

        cadFile.SetActiveLayer(layerName);

        int totalDrawn = 0;

        for (int i = 0; i < sampledCurves.Count; i++)
        {
            List<Point3F> curvePoints = sampledCurves[i];

            for (int j = 0; j < curvePoints.Count; j++)
            {
                if (totalDrawn >= maxPoints)
                {
                    return; // evita sobrecarga
                }

                Point3F pt = curvePoints[j];
                Circle marker = new Circle(pt, markerRadius);
                cadFile.Add(marker);
                totalDrawn++;
            }
        }
    }
}