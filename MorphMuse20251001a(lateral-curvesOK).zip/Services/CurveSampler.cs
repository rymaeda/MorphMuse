﻿using CamBam.CAD;
using CamBam.Geom;
using MorphMuse.Services;
using System.Collections.Generic;

public static class CurveSampler
{
    public static List<List<Point3F>> GenerateSampledPointsFromContours(
        List<List<Polyline>> orderedContours,
        List<Point3F> simplifiedGeratriz,
        double baseDensity,
        double minStep)
    {
        var sampledCurves = new List<List<Point3F>>();

        for (int i = 0; i < orderedContours.Count; i++)
        {
            List<Polyline> curves = orderedContours[i];
            double step = baseDensity;

            if (i < simplifiedGeratriz.Count - 1)
            {
                Point3F p1 = simplifiedGeratriz[i];
                Point3F p2 = simplifiedGeratriz[i + 1];
                Vector3F delta = new Vector3F(p2.X - p1.X, p2.Y - p1.Y, p2.Z - p1.Z);

                double spacing = Geometry3F.Length(delta);
                step = spacing * baseDensity;
                if (step < minStep)
                {
                    step = minStep;
                }
            }

            for (int j = 0; j < curves.Count; j++)
            {
                Polyline curve = curves[j];
                PointList rawPoints = PointListUtils.CreatePointlistFromPolylineStep(curve, step);

                List<Point3F> converted = new List<Point3F>();
                for (int k = 0; k < rawPoints.Points.Count; k++)
                {
                    converted.Add(rawPoints.Points[k]);
                }

                sampledCurves.Add(converted);
            }
        }

        return sampledCurves;
    }
}