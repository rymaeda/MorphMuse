﻿using CamBam.CAD;
using CamBam.Geom;
using CamBam.UI;
using MorphMuse.Services;
using System.Collections.Generic;
using System.Drawing;

public class MorphMuseController
{
    private readonly CamBamUI _ui;

    public MorphMuseController(CamBamUI ui)
    {
        _ui = ui;
    }

    public void Execute()
    {
        if (!PolylineManager.TryCreateFromSelection(out PolylineManager manager))
            return;
        var processor = new OpenPolylineProcessor(manager.OpenPoly, 0.01, 0.01);
        var orderedContours = LayerGenerator.GenerateContoursByGeratrizOrder(manager.ClosedPoly, processor.SimplifiedPoints);
        var sampledCurves = CurveSampler.GenerateSampledPointsFromContours(orderedContours, processor.SimplifiedPoints, 0.05, 0.05);
        var simplifiedCurves = SimplifyAll(sampledCurves);
        string ActiveLayerName = _ui.ActiveView.CADFile.ActiveLayerName;

        if (simplifiedCurves.Count < 2)
            return;

        // Cria um único layer para a malha final
        string layerName = CreateUniqueLayer("Mesh");
        Layer layer = _ui.ActiveView.CADFile.Layers[layerName];
        layer.Color = Color.DeepSkyBlue;

        // Estruturas acumuladoras
        Point3FArray allPoints = new Point3FArray();
        Dictionary<Point3F, int> pointIndex = new Dictionary<Point3F, int>();
        List<TriangleFace> allFaces = new List<TriangleFace>();

        for (int i = 0; i < simplifiedCurves.Count - 1; i++)
        {
            var lower = simplifiedCurves[i];
            var upper = simplifiedCurves[i + 1];

            // Gera a malha parcial entre duas curvas
            Surface parcial = SurfaceBuilderCopilot.BuildSurfaceBetweenCurves(lower, upper);

            // Reindexa os pontos da malha parcial para a malha final
            for (int f = 0; f < parcial.Faces.Length; f++)
            {
                TriangleFace face = parcial.Faces[f];

                Point3F pa = parcial.Points[face.A];
                Point3F pb = parcial.Points[face.B];
                Point3F pc = parcial.Points[face.C];

                int ia = AddPoint(pa, allPoints, pointIndex);
                int ib = AddPoint(pb, allPoints, pointIndex);
                int ic = AddPoint(pc, allPoints, pointIndex);

                allFaces.Add(new TriangleFace(ia, ib, ic));
            }
        }

        // Cria a malha final consolidada
        Surface finalSurface = new Surface();
        finalSurface.Points = allPoints;
        finalSurface.Faces = allFaces.ToArray();

        // Adiciona ao layer único
        _ui.ActiveView.CADFile.Add(finalSurface);
        _ui.ActiveView.CADFile.SetActiveLayer(ActiveLayerName);
        _ui.ActiveView.ZoomToFit();
        _ui.ActiveView.RefreshView();
    }

    private int AddPoint(Point3F p, Point3FArray points, Dictionary<Point3F, int> indexMap)
    {
        int index;
        if (!indexMap.TryGetValue(p, out index))
        {
            index = points.Count;
            points.Add(p);
            indexMap[p] = index;
        }
        return index;
    }
    private List<List<Point3F>> SimplifyAll(List<List<Point3F>> curves)
    {
        var result = new List<List<Point3F>>();
        foreach (var curve in curves)
            result.Add(PolylineSimplifier.SimplifyDouglasPeucker(curve, 0.001));
        return result;
    }

    private string CreateUniqueLayer(string baseName)
    {
        int index = 1;
        string layerName;
        var cadFile = _ui.ActiveView.CADFile;

        do
        {
            layerName = $"{baseName}{index:D4}";
            index++;
        }
        while (cadFile.HasLayer(layerName));

        cadFile.CreateLayer(layerName);
        cadFile.SetActiveLayer(layerName);
        return layerName;
    }
}