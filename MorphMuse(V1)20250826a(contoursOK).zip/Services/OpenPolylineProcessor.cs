﻿using CamBam.CAD;
using CamBam.Geom;
using System.Collections.Generic;

namespace MorphMuse.Services
{
    internal class OpenPolylineProcessor
    {
        public List<Point3F> SimplifiedPoints { get; private set; }

        public OpenPolylineProcessor(Polyline openPolyline, double arcTolerance = 0.1, double simplifyTolerance = 0.5)
        {
            SimplifiedPoints = new List<Point3F>();

            if (openPolyline != null && !openPolyline.Closed && openPolyline.Points.Count > 0)
            {
                // 1. Remove arcos
                Polyline linearized = openPolyline.RemoveArcs(arcTolerance);

                // 2. Define origem como o primeiro ponto
                Point3F origin = linearized.Points[0].Point;

                // 3. Extrai pontos transladados manualmente
                List<Point3F> translatedPoints = new List<Point3F>();
                foreach (PolylineItem item in linearized.Points)
                {
                    Point3F pt = item.Point;
                    Point3F relative = new Point3F(
                        pt.X - origin.X,
                        pt.Y - origin.Y,
                        pt.Z - origin.Z
                    );
                    translatedPoints.Add(relative);
                }

                // 4. Aplica simplificação
                SimplifiedPoints = PolylineSimplifier.DouglasPeucker(translatedPoints, simplifyTolerance);
            }
        }

        public int Count => SimplifiedPoints.Count;
        public Point3F this[int index] => SimplifiedPoints[index];
    }
}