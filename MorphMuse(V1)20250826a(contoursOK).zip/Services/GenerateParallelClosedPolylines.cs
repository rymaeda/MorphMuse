﻿using CamBam.CAD;
using CamBam.Geom;
using System;
using System.Collections.Generic;

namespace MorphMuse.Services
{
    internal static class LayerGenerator
    {
        public static List<Polyline> GenerateParallelClosedPolylines(
            Polyline closedBase,
            List<Point3F> openReferencePoints)
        {
            var contours = new List<Polyline>();
            /*if (closedBase == null)
                throw new ArgumentNullException(nameof(closedBase), "Polilinha fechada não foi inicializada.");
            if (openReferencePoints == null || openReferencePoints.Count == 0)
                throw new ArgumentException("Lista de pontos da polilinha aberta está vazia ou nula.");
            */
            foreach (Point3F refPt in openReferencePoints)
            {
                float offsetValue = (float)refPt.X;
                float zHeight = (float)refPt.Y;

                // Usa o método nativo da API para gerar polilinha paralela
                Polyline[] offsetLayers = closedBase.CreateOffsetPolyline(offsetValue, 0.01f);
                if (offsetLayers == null || offsetLayers.Length == 0)
                {
                    CamBam.ThisApplication.AddLogMessage($"offsetValue: {offsetValue} // offsetLayers.Length: {(offsetLayers != null ? offsetLayers.Length.ToString() : "nulo")}");
                    continue; // ou logar e seguir
                              // 
                }
                foreach (Polyline layer in offsetLayers)
                {
                    // Aplica altura Z a todos os pontos
                    for (int i = 0; i < layer.Points.Count; i++)
                    {
                        PolylineItem item = layer.Points[i];
                        Point3F pt = item.Point;
                        pt.Z = zHeight;
                        item.Point = pt;
                        layer.Points[i] = item; // ✅ reatribui o item modificado
                    }

                    //layer.SetColor(System.Drawing.Color.MediumPurple);
                    contours.Add(layer);
                }
            }

            return contours;
        }
    }
}