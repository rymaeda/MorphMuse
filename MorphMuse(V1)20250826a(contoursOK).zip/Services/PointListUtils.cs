﻿using CamBam.CAD;
using CamBam.Geom;
using System.Collections.Generic;

namespace MorphMuse.Services
{
    internal static class PointListUtils
    {
        public static List<Point3F> CreateRelativePointList(Polyline polyline)
        {
            var relativePoints = new List<Point3F>();

            if (polyline == null || polyline.Points.Count == 0)
                return relativePoints;

            Point3F origin = polyline.Points[0].Point;

            foreach (PolylineItem item in polyline.Points)
            {
                Point3F pt = item.Point;
                Point3F relative = new Point3F(
                    pt.X - origin.X,
                    pt.Y - origin.Y,
                    pt.Z - origin.Z
                );

                relativePoints.Add(relative);
            }

            return relativePoints;
        }
    }
}