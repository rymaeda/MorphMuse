﻿using CamBam.CAD;
using CamBam.Geom;
using CamBam.UI;
using CamBam.Util;
using MorphMuse;
//using MorphMuse.Model;
using MorphMuse.Services;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace CambamPlugin
{
    public class Program
    {
        public static CamBamUI _ui;
        // This is the main entry point into the plugin.
        public static void InitPlugin(CamBamUI ui)
        {
            // Store a reference to the CamBamUI object passed to InitPlugin
            _ui = ui;

            // Create a new menu item in the top Plugins menu
            ToolStripMenuItem mi = new ToolStripMenuItem();
            mi.Text = "MorphMuse";
            mi.Click += new EventHandler(MorphMuse_Click);
            ui.Menus.mnuPlugins.DropDownItems.Add(mi);
        }

        static void MorphMuse_Click(object sender, EventArgs e)
        {
            if (!PolylineManager.TryCreateFromSelection(out PolylineManager manager))
                return;

            // Processa a polilinha aberta
            OpenPolylineProcessor processor = new OpenPolylineProcessor(manager.OpenPoly, 0.1, 0.3);

            // Gera as camadas paralelas
            List<Polyline> layers = LayerGenerator.GenerateParallelClosedPolylines(
                manager.ClosedPoly,
                processor.SimplifiedPoints
            );

            // Adiciona ao desenho
            foreach (var layer in layers)
            {
                CamBam.ThisApplication.AddLogMessage("Cheguei aki tb.");
                //layer.SetColor(Color.MediumPurple);
                CamBamUI.MainUI.ActiveView.CADFile.Add(layer);
            }
            _ui.ActiveView.ZoomToFit();
            _ui.ActiveView.RefreshView();
            //MessageBox.Show($"{layers.Count} camadas geradas com sucesso.");
        }
    }// class
}