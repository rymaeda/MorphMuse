﻿using CamBam.CAD;
using CamBam.Geom;
using CamBam.UI;
using CamBam.Util;
using MorphMuse;
//using MorphMuse.Model;
using MorphMuse.Services;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace CambamPlugin
{
    public class Program
    {
        public static CamBamUI _ui;
        // This is the main entry point into the plugin.
        public static void InitPlugin(CamBamUI ui)
        {
            // Store a reference to the CamBamUI object passed to InitPlugin
            _ui = ui;

            // Create a new menu item in the top Plugins menu
            ToolStripMenuItem mi = new ToolStripMenuItem();
            mi.Text = "MorphMuse";
            mi.Click += new EventHandler(MorphMuse_Click);
            ui.Menus.mnuPlugins.DropDownItems.Add(mi);
        }

        static void MorphMuse_Click(object sender, EventArgs e)
        {
            if (!PolylineManager.TryCreateFromSelection(out PolylineManager manager))
                return;
            Layer layer = _ui.ActiveView.CADFile.CreateLayer("ParallelCurves");
            _ui.ActiveView.CADFile.SetActiveLayer("ParallelCurves");
            layer.Color = Color.DodgerBlue;

            // Openpoly treatament
            OpenPolylineProcessor processor = new OpenPolylineProcessor(manager.OpenPoly, 0.1, 0.3);

            // Generate layers - simple initial version
            //List<Polyline> layers = LayerGenerator.GenerateParallelClosedPolylines(
            //    manager.ClosedPoly,
            //    processor.SimplifiedPoints
            //);

            // Generate grouped layers with adaptive curves
            var groupedContours = LayerGenerator.GenerateAdaptiveContoursGrouped(manager.ClosedPoly, processor.SimplifiedPoints);

            foreach (var kvp in groupedContours.OrderBy(k => k.Key))
            {
                float z = kvp.Key;
                List<Polyline> curves = kvp.Value;

                foreach (var curve in curves)
                {
                    // Adiciona ao desenho
                    CamBamUI.MainUI.ActiveView.CADFile.Add(curve);
                }
            }

            foreach (var kvp in groupedContours)
            {
                float z = kvp.Key;
                List<Polyline> curves = kvp.Value;

                foreach (var curve in curves)
                {
                    // Exemplo: aplicar cor ou nome baseado na altura
                    // curve.SetColor(Color.FromArgb((int)(z * 50) % 255, 100, 200));
                    CamBamUI.MainUI.ActiveView.CADFile.Add(curve);
                }
            }
            _ui.ActiveView.ZoomToFit();
            _ui.ActiveView.RefreshView();
            //MessageBox.Show($"{layers.Count} camadas geradas com sucesso.");
        }
    }// class
}