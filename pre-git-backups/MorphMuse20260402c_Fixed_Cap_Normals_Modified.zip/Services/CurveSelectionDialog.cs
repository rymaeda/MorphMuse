using CamBam.CAD;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace MorphMuse.Services
{
    public class CurveSelectionDialog : Form
    {
        private GroupBox grpCurve1;
        private GroupBox grpCurve2;
        private RadioButton rbCurve1AsRail;
        private RadioButton rbCurve1AsForm;
        private RadioButton rbCurve2AsRail;
        private RadioButton rbCurve2AsForm;
        private Button btnOk;
        private Button btnCancel;
        private Label lblCurve1Info;
        private Label lblCurve2Info;
        private List<Polyline> _openCurves;

        public Polyline SelectedRail { get; private set; }
        public Polyline SelectedForm { get; private set; }

        public CurveSelectionDialog(List<Polyline> openCurves)
        {
            _openCurves = openCurves;
            InitializeComponent();
            PopulateInfo();
        }

        private void InitializeComponent()
        {
            this.Text = "Select Rail and Form Curves";
            this.Size = new Size(550, 350);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterParent;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            // Title label
            Label lblTitle = new Label()
            {
                Text = "Select which curve is the Rail (path) and which is the Form (profile):",
                Location = new Point(20, 15),
                AutoSize = true,
                Font = new Font(this.Font, FontStyle.Bold)
            };

            // ===== CURVE 1 GROUP =====
            grpCurve1 = new GroupBox()
            {
                Text = "Curve 1",
                Location = new Point(20, 45),
                Size = new Size(500, 120),
                TabStop = false
            };

            lblCurve1Info = new Label()
            {
                Location = new Point(15, 25),
                AutoSize = true,
                Font = new Font(this.Font, FontStyle.Regular)
            };

            rbCurve1AsRail = new RadioButton()
            {
                Text = "Use as Rail (path to be offset)",
                Location = new Point(15, 50),
                AutoSize = true,
                Checked = true
            };

            rbCurve1AsForm = new RadioButton()
            {
                Text = "Use as Form (profile definition)",
                Location = new Point(15, 75),
                AutoSize = true
            };

            grpCurve1.Controls.Add(lblCurve1Info);
            grpCurve1.Controls.Add(rbCurve1AsRail);
            grpCurve1.Controls.Add(rbCurve1AsForm);

            // ===== CURVE 2 GROUP =====
            grpCurve2 = new GroupBox()
            {
                Text = "Curve 2",
                Location = new Point(20, 175),
                Size = new Size(500, 120),
                TabStop = false
            };

            lblCurve2Info = new Label()
            {
                Location = new Point(15, 25),
                AutoSize = true,
                Font = new Font(this.Font, FontStyle.Regular)
            };

            rbCurve2AsRail = new RadioButton()
            {
                Text = "Use as Rail (path to be offset)",
                Location = new Point(15, 50),
                AutoSize = true
            };

            rbCurve2AsForm = new RadioButton()
            {
                Text = "Use as Form (profile definition)",
                Location = new Point(15, 75),
                AutoSize = true,
                Checked = true
            };

            grpCurve2.Controls.Add(lblCurve2Info);
            grpCurve2.Controls.Add(rbCurve2AsRail);
            grpCurve2.Controls.Add(rbCurve2AsForm);

            // ===== BUTTONS =====
            btnOk = new Button()
            {
                Text = "OK",
                Location = new Point(340, 310),
                Size = new Size(80, 30),
                DialogResult = DialogResult.OK
            };
            btnOk.Click += BtnOk_Click;

            btnCancel = new Button()
            {
                Text = "Cancel",
                Location = new Point(430, 310),
                Size = new Size(80, 30),
                DialogResult = DialogResult.Cancel
            };

            // Add all controls to form
            this.Controls.Add(lblTitle);
            this.Controls.Add(grpCurve1);
            this.Controls.Add(grpCurve2);
            this.Controls.Add(btnOk);
            this.Controls.Add(btnCancel);

            this.AcceptButton = btnOk;
            this.CancelButton = btnCancel;
        }

        private void PopulateInfo()
        {
            if (_openCurves.Count >= 2)
            {
                lblCurve1Info.Text = GetCurveIdentification(_openCurves[0]);
                lblCurve2Info.Text = GetCurveIdentification(_openCurves[1]);
            }
        }

        /// <summary>
        /// Gets a detailed identification string for a polyline using CamBam API best practices.
        /// Includes: Type, ID, Layer, Point Count, and Closed status.
        /// </summary>
        private string GetCurveIdentification(Polyline curve)
        {
            // Get entity type using PrimitiveType (CamBam-specific, most readable)
            string primitiveType = curve.PrimitiveType;

            // Get ID (every entity has this)
            int id = curve.ID;

            // Get layer name
            string layerName = curve.Layer != null ? curve.Layer.Name : "Unknown";

            // Get point count
            int pointCount = curve.Points.Count;

            // Get closed status
            bool isClosed = curve.Closed;
            string closedStatus = isClosed ? "Closed" : "Open";

            // Build comprehensive identification string
            return $"Type: {primitiveType} | ID: {id} | Layer: {layerName} | Points: {pointCount} | Status: {closedStatus}";
        }

        private void BtnOk_Click(object sender, EventArgs e)
        {
            // Determine which curve is rail and which is form based on radio button selections
            if (rbCurve1AsRail.Checked)
            {
                SelectedRail = _openCurves[0];
                SelectedForm = _openCurves[1];
            }
            else
            {
                SelectedRail = _openCurves[1];
                SelectedForm = _openCurves[0];
            }

            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
