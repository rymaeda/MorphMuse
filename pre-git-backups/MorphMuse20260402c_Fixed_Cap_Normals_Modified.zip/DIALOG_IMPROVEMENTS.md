# CurveSelectionDialog - Improvements Documentation

## Overview

The `CurveSelectionDialog` has been significantly improved to provide better user experience and more robust curve identification. The dialog now uses radio-buttons for clear role selection and displays comprehensive curve information using CamBam API best practices.

## Key Improvements

### 1. Radio-Button Interface

**Before:** Dropdown menus (ComboBox) that could be confusing about which curve was which.

**After:** Two separate group boxes with radio-buttons for each curve, making the role selection explicit and intuitive.

```
┌─────────────────────────────────────────────────────────┐
│ Select Rail and Form Curves                             │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ ┌─ Curve 1 ──────────────────────────────────────────┐ │
│ │ Type: Polyline | ID: 42 | Layer: Default | ...    │ │
│ │ ○ Use as Rail (path to be offset)                 │ │
│ │ ○ Use as Form (profile definition)                │ │
│ └─────────────────────────────────────────────────────┘ │
│                                                         │
│ ┌─ Curve 2 ──────────────────────────────────────────┐ │
│ │ Type: Polyline | ID: 43 | Layer: Default | ...    │ │
│ │ ○ Use as Rail (path to be offset)                 │ │
│ │ ○ Use as Form (profile definition)                │ │
│ └─────────────────────────────────────────────────────┘ │
│                                                         │
│                              [OK]      [Cancel]        │
└─────────────────────────────────────────────────────────┘
```

### 2. Robust Curve Identification

**Before:** Used only ID and layer name, which could be insufficient for disambiguation.

**After:** Uses the `GetCurveIdentification()` method that provides comprehensive information:

| Information | Source | Purpose |
|-------------|--------|---------|
| **Type** | `curve.PrimitiveType` | Shows entity type (Polyline, Circle, etc.) |
| **ID** | `curve.ID` | Unique identifier in the drawing |
| **Layer** | `curve.Layer.Name` | Layer where the curve is located |
| **Point Count** | `curve.Points.Count` | Number of vertices in the polyline |
| **Status** | `curve.Closed` | Indicates if curve is open or closed |

**Example Output:**
```
Type: Polyline | ID: 42 | Layer: Default | Points: 15 | Status: Open
Type: Polyline | ID: 43 | Layer: Profiles | Points: 8 | Status: Open
```

### 3. API Best Practices

The implementation follows CamBam API best practices as documented in the `CamBamEntityIdentificationQuickReference.md`:

- **Uses `PrimitiveType`** instead of `GetType().Name` for human-readable type identification
- **Accesses `ID` property** directly (read-only, always available)
- **Checks for null Layer** before accessing its properties
- **Follows CamBam naming conventions** and API patterns

### 4. Improved User Experience

**Default Selection:** 
- Curve 1 is pre-selected as Rail
- Curve 2 is pre-selected as Form
- User can quickly confirm if this matches their intent

**Clear Descriptions:**
- Each radio-button is labeled with the role description
- "Rail (path to be offset)" - explains what the rail does
- "Form (profile definition)" - explains what the form does

**Visual Organization:**
- Each curve is in its own group box
- Information is displayed above the radio-buttons
- Buttons are clearly positioned at the bottom

## Implementation Details

### GetCurveIdentification Method

```csharp
private string GetCurveIdentification(Polyline curve)
{
    string primitiveType = curve.PrimitiveType;  // CamBam-specific, most readable
    int id = curve.ID;                           // Every entity has this
    string layerName = curve.Layer != null ? curve.Layer.Name : "Unknown";
    int pointCount = curve.Points.Count;
    bool isClosed = curve.Closed;
    string closedStatus = isClosed ? "Closed" : "Open";

    return $"Type: {primitiveType} | ID: {id} | Layer: {layerName} | Points: {pointCount} | Status: {closedStatus}";
}
```

### Role Selection Logic

```csharp
private void BtnOk_Click(object sender, EventArgs e)
{
    if (rbCurve1AsRail.Checked)
    {
        SelectedRail = _openCurves[0];
        SelectedForm = _openCurves[1];
    }
    else
    {
        SelectedRail = _openCurves[1];
        SelectedForm = _openCurves[0];
    }
}
```

The logic is straightforward: check which radio-button is selected and assign the curves accordingly.

## Usage in PolylineManager

The dialog is invoked when two open curves are detected:

```csharp
else if (closedCount == 0 && openCount == 2)
{
    using (var dialog = new CurveSelectionDialog(openPolys))
    {
        if (dialog.ShowDialog() == DialogResult.OK)
        {
            manager = new PolylineManager(dialog.SelectedRail, dialog.SelectedForm, true)
            {
                CounterClosedP = closedCount,
                CounterOpenP = openCount
            };
            return true;
        }
    }
    return false;
}
```

## Testing the Dialog

### Test Case 1: Basic Display
1. Select two open polylines
2. Invoke the plugin
3. Verify the dialog appears with both curves identified
4. Verify default selections (Curve 1 as Rail, Curve 2 as Form)

### Test Case 2: Role Selection
1. Click the radio-button to swap roles
2. Verify only one radio-button per curve is selected
3. Click OK and verify the surface is generated with the correct role assignment

### Test Case 3: Curve Information Display
1. Create curves on different layers
2. Create curves with different point counts
3. Verify all information is displayed correctly in the dialog

### Test Case 4: Cancel Operation
1. Open the dialog
2. Click Cancel
3. Verify the plugin exits without generating a surface

## Advantages Over Previous Implementation

| Aspect | Previous | Improved |
|--------|----------|----------|
| **Interface** | Dropdown menus | Radio-buttons (clearer intent) |
| **Identification** | ID + Layer only | Type + ID + Layer + Points + Status |
| **API Usage** | Custom layer name access | CamBam best practices (PrimitiveType) |
| **Default Selection** | Manual selection required | Pre-selected sensible defaults |
| **User Clarity** | Role descriptions in dropdown | Explicit role descriptions with radio-buttons |
| **Visual Organization** | Compact but unclear | Organized in group boxes |

## Future Enhancements

Potential improvements for future versions:

1. **Preview Highlighting:** Highlight the selected curves in the drawing while the dialog is open
2. **Curve Thumbnails:** Display small visual previews of each curve
3. **Geometric Properties:** Show bounding box dimensions and curve length
4. **Auto-Detection:** Attempt to automatically detect which curve should be rail vs form based on geometry
5. **Curve Comparison:** Display differences between the curves to help users make informed decisions

## Conclusion

The improved `CurveSelectionDialog` provides a more intuitive and informative interface for disambiguating curve roles. By leveraging CamBam API best practices and providing comprehensive curve information, users can confidently select which curve serves as the rail and which serves as the form.
