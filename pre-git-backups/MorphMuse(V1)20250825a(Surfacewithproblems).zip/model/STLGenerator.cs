﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MorphMuse.model
{
    internal class STLGenerator
    {
        public void Export(string filePath, List<Triangle> triangles)
        {
            // Escreve o arquivo STL
        }

    }
}
