﻿using CamBam.CAD;
using CamBam.Geom;
using CamBam.UI;
using CamBam.Util;
using MorphMuse;
using MorphMuse.Model;
using MorphMuse.Services;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace CambamPlugin
{
    public class Program
    {
        public static CamBamUI _ui;
        // This is the main entry point into the plugin.
        public static void InitPlugin(CamBamUI ui)
        {
            // Store a reference to the CamBamUI object passed to InitPlugin
            _ui = ui;

            // Create a new menu item in the top Plugins menu
            ToolStripMenuItem mi = new ToolStripMenuItem();
            mi.Text = "MorphMuse";
            mi.Click += new EventHandler(MorphMuse_Click);
            ui.Menus.mnuPlugins.DropDownItems.Add(mi);
        }

        static void MorphMuse_Click(object sender, EventArgs e)
        {
            ICADView view = _ui.ActiveView;

            try
            {
                if (PolylineManager.TryCreateFromSelection(out var manager))
                {
                    const string layerName = "BevelerTest";

                    // 1. Create layer if needed
                    if (!view.CADFile.HasLayer(layerName))
                    {
                        Layer layer = view.CADFile.CreateLayer(layerName);
                        layer.Color = Color.Fuchsia;
                    }
                    view.CADFile.SetActiveLayer(layerName);
                    view.RefreshView();

                    // 2. Generate offsets from base polyline
                    List<PointSamples> layers = new List<PointSamples>();
                    for (int i = 1; i <= 9; i++)
                    {
                        if (i == 0) continue; // jump base polyline
                        double offsetValue = i * 4.0;
                        Polyline[] offsetResult = manager.ClosedPoly.CreateOffsetPolyline(offsetValue, 0.01);

                        if (offsetResult != null && offsetResult.Length > 0)
                        {
                            foreach (Polyline p in offsetResult)
                            {
                                layers.Add(new PointSamples(p));
                            }
                        }
                    }

                    // 3. Generate triangles connecting the layers
                    SurfaceGenerator generator = new SurfaceGenerator();
                    List<Triangle> triangles = generator.GenerateSurface(layers);

                    // 4. Build CamBam Surface
                    StlSurfaceBuilder builder = new StlSurfaceBuilder();
                    foreach (var tri in triangles)
                    {
                        builder.AddTriangle(tri.A, tri.B, tri.C);
                    }

                    Surface surface = builder.Build();
                    view.CADFile.Layers[layerName].Entities.Add(surface);
                    //surface.Color = Color.LightSteelBlue;

                    // 5. Add to drawing
                    view.CADFile.Add(surface);
                    view.ZoomToFit();
                }
            }
            catch (Exception errormessage)
            {
                MessageBox.Show(TextTranslation.Translate("Streamlines tracer Fatal Error\n") + errormessage);
                return;
            }
        }
    }// class
}