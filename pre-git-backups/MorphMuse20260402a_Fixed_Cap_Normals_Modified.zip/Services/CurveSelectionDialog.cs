using CamBam.CAD;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace MorphMuse.Services
{
    public class CurveSelectionDialog : Form
    {
        private ComboBox cmbRail;
        private ComboBox cmbForm;
        private Button btnOk;
        private Button btnCancel;
        private List<Polyline> _openCurves;

        public Polyline SelectedRail { get; private set; }
        public Polyline SelectedForm { get; private set; }

        public CurveSelectionDialog(List<Polyline> openCurves)
        {
            _openCurves = openCurves;
            InitializeComponent();
            PopulateComboBoxes();
        }

        private void InitializeComponent()
        {
            this.Text = "Select Rail and Form Curves";
            this.Size = new Size(350, 200);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterParent;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            Label lblRail = new Label() { Text = "Rail Curve:", Location = new Point(20, 20), AutoSize = true };
            cmbRail = new ComboBox() { Location = new Point(120, 20), Width = 180, DropDownStyle = ComboBoxStyle.DropDownList };
            cmbRail.SelectedIndexChanged += CmbRail_SelectedIndexChanged;

            Label lblForm = new Label() { Text = "Form Curve:", Location = new Point(20, 60), AutoSize = true };
            cmbForm = new ComboBox() { Location = new Point(120, 60), Width = 180, DropDownStyle = ComboBoxStyle.DropDownList };
            cmbForm.SelectedIndexChanged += CmbForm_SelectedIndexChanged;

            btnOk = new Button() { Text = "OK", Location = new Point(120, 110), DialogResult = DialogResult.OK };
            btnOk.Click += BtnOk_Click;
            
            btnCancel = new Button() { Text = "Cancel", Location = new Point(210, 110), DialogResult = DialogResult.Cancel };

            this.Controls.Add(lblRail);
            this.Controls.Add(cmbRail);
            this.Controls.Add(lblForm);
            this.Controls.Add(cmbForm);
            this.Controls.Add(btnOk);
            this.Controls.Add(btnCancel);
            
            this.AcceptButton = btnOk;
            this.CancelButton = btnCancel;
        }

        private void PopulateComboBoxes()
        {
            foreach (var curve in _openCurves)
            {
                // Use ID and layer information to identify curves
                string layerName = curve.Layer != null ? curve.Layer.Name : "Unknown";
                string displayName = $"Polyline ID: {curve.ID} (Layer: {layerName})";
                cmbRail.Items.Add(displayName);
                cmbForm.Items.Add(displayName);
            }
            
            if (cmbRail.Items.Count > 0) cmbRail.SelectedIndex = 0;
            if (cmbForm.Items.Count > 1) cmbForm.SelectedIndex = 1;
        }

        private void CmbRail_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbRail.SelectedIndex == cmbForm.SelectedIndex)
            {
                cmbForm.SelectedIndex = (cmbRail.SelectedIndex + 1) % _openCurves.Count;
            }
        }

        private void CmbForm_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbForm.SelectedIndex == cmbRail.SelectedIndex)
            {
                cmbRail.SelectedIndex = (cmbForm.SelectedIndex + 1) % _openCurves.Count;
            }
        }

        private void BtnOk_Click(object sender, EventArgs e)
        {
            SelectedRail = _openCurves[cmbRail.SelectedIndex];
            SelectedForm = _openCurves[cmbForm.SelectedIndex];
        }
    }
}
