# Funcionalidade de Geração de Superfícies a Partir de Duas Curvas Abertas no Plugin MorphMuse

Esta documentação detalha as alterações implementadas para permitir a geração de superfícies laterais a partir de duas polilinhas abertas, sem a criação de tampas de fechamento.

## 1. Cenários de Seleção Suportados

O `PolylineManager.cs` foi atualizado para reconhecer e validar dois cenários distintos de seleção de polilinhas:

*   **Cenário 1: Volume com Tampa (Comportamento Original)**
    *   **Seleção:** Uma polilinha fechada e uma polilinha aberta.
    *   **Resultado:** Geração de um volume 3D com superfície lateral e uma tampa de fechamento (utilizando o algoritmo de Ear Clipping).

*   **Cenário 2: Superfície Lateral de Curvas Abertas (Nova Funcionalidade)**
    *   **Seleção:** Duas polilinhas abertas.
    *   **Resultado:** Geração de uma superfície 3D conectando as duas polilinhas abertas, sem a criação de tampas.

Uma mensagem de erro será exibida caso a seleção não se enquadre em nenhum desses cenários.

## 2. Fluxo de Execução no `MorphMuseController.cs`

O método `Execute()` no `MorphMuseController.cs` foi modificado para direcionar o processamento com base no tipo de seleção:

*   **`ExecuteVolumeWithCap(selectionManager)`:** Este método é invocado quando o Cenário 1 (uma polilinha fechada e uma aberta) é detectado. Ele mantém o fluxo original de geração de volume, incluindo a chamada para `SurfaceBuilderCopilot.GenerateLateralSurface` (com `isClosed: true`) e `SurfaceBuilderCopilot.GenerateCapSurface`.

*   **`ExecuteSurfaceBetweenOpenCurves(selectionManager)`:** Este é o novo método responsável por lidar com o Cenário 2 (duas polilinhas abertas). Seu fluxo é o seguinte:
    1.  **Obtenção das Curvas:** As duas polilinhas abertas selecionadas são extraídas do `selectionManager`.
    2.  **Preparação das Curvas:** As curvas são convertidas para `List<Point3F>` e simplificadas usando o algoritmo Douglas-Peucker, com base nas tolerâncias definidas. Conforme discutido, a amostragem e o alinhamento são considerados adequados para curvas geradas por offset.
    3.  **Geração da Superfície Lateral:** A função `SurfaceBuilderCopilot.GenerateLateralSurface` é chamada com as duas curvas abertas e o parâmetro `isClosed` definido como `false`. Isso garante que a lógica de alinhamento circular e fechamento de extremidades não seja aplicada, resultando em uma superfície aberta.
    4.  **Sem Geração de Tampa:** **Nenhuma chamada** para `SurfaceBuilderCopilot.GenerateCapSurface` é feita neste fluxo, garantindo que a superfície permaneça aberta.
    5.  **Adição ao CAD:** A superfície resultante é adicionada a uma nova camada no arquivo CAD.

## 3. Adaptações no `SurfaceBuilderCopilot.cs`

O método `BuildSurfaceBetweenCurves` e `GenerateLateralSurface` já haviam sido refatorados para aceitar um parâmetro `isClosed`. Esta adaptação é crucial para a nova funcionalidade, pois permite que a lógica de fechamento e alinhamento circular seja condicionalmente aplicada apenas quando necessário.

## 4. Como Utilizar a Nova Funcionalidade

Para gerar uma superfície entre duas curvas abertas:

1.  No CamBam, selecione **exatamente duas polilinhas abertas**.
2.  Execute o plugin MorphMuse.
3.  O plugin detectará automaticamente a seleção e gerará a superfície lateral entre as duas curvas, sem adicionar tampas.
