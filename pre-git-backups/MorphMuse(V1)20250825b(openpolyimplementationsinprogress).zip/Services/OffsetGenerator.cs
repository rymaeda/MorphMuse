﻿using CamBam.CAD;
using CamBam.Geom;
using CamBam.UI;
using System;
using System.Collections.Generic;


namespace MorphMuse
{
    public static class OffsetGenerator
    {
        public static List<Polyline> GenerateOffsets(Polyline original, double spacing, int numPositive, int numNegative)
        {
            List<Polyline> result = new List<Polyline>();

            for (int i = 1; i <= numPositive; i++)
            {
                double d = spacing * i;
                var offset = GenerateOffsetPolyline(original, d);
                if (offset != null) result.Add(offset);
            }

            for (int i = 1; i <= numNegative; i++)
            {
                double d = -spacing * i;
                var offset = GenerateOffsetPolyline(original, d);
                if (offset != null) result.Add(offset);
            }

            return result;
        }

        private static Polyline GenerateOffsetPolyline(Polyline original, double offsetDistance)
        {
            if (!original.Closed || original.Points.Count < 3)
                return null;

            List<Point2F> offsetPoints = new List<Point2F>();
            int count = original.Points.Count;

            for (int i = 0; i < count; i++)
            {
                Point2F prev = original.Points[(i - 1 + count) % count];
                Point2F current = original.Points[i];
                Point2F next = original.Points[(i + 1) % count];

                Vector2D normal = GetSmoothedNormal(prev, current, next);
                Point2F offsetPoint = current + normal * offsetDistance;

                offsetPoints.Add(offsetPoint);
            }

            Polyline offsetPolyline = new Polyline();
            offsetPolyline.Closed = true;
            offsetPolyline.Points.AddRange(offsetPoints);

            return offsetPolyline;
        }

        private static Vector2D GetSmoothedNormal(Point2F prev, Point2F current, Point2F next)
        {
            Vector2D dir1 = current - prev;
            Vector2D dir2 = next - current;

            dir1.Normalize();
            dir2.Normalize();

            Vector2D normal1 = new Vector2D(-dir1.Y, dir1.X);
            Vector2D normal2 = new Vector2D(-dir2.Y, dir2.X);

            Vector2D avgNormal = (normal1 + normal2) / 2.0;
            avgNormal.Normalize();

            return avgNormal;
        }

        public static List<Polyline> GenerateSmartOffsets(
    Polyline original,
    double baseSpacing,
    int numPositive,
    int numNegative,
    double curvatureFactor = 0.5,
    double minSpacing = 0.2)
        {
            List<Polyline> result = new List<Polyline>();

            for (int i = 1; i <= numPositive; i++)
            {
                double spacing = AdjustSpacing(original, baseSpacing * i, curvatureFactor, minSpacing);
                var offset = GenerateOffsetPolyline(original, spacing);
                if (offset != null && !HasSelfIntersection(offset))
                    result.Add(offset);
            }

            for (int i = 1; i <= numNegative; i++)
            {
                double spacing = AdjustSpacing(original, -baseSpacing * i, curvatureFactor, minSpacing);
                var offset = GenerateOffsetPolyline(original, spacing);
                if (offset != null && !HasSelfIntersection(offset))
                    result.Add(offset);
            }

            return result;
        }
        private static double AdjustSpacing(Polyline poly, double spacing, double factor, double min)
        {
            double avgAngle = 0;
            int count = poly.Points.Count;

            for (int i = 0; i < count; i++)
            {
                Point2F prev = poly.Points[(i - 1 + count) % count];
                Point2F current = poly.Points[i];
                Point2F next = poly.Points[(i + 1) % count];

                Vector2D v1 = current - prev;
                Vector2D v2 = next - current;

                v1.Normalize();
                v2.Normalize();

                double angle = Math.Acos(Math.Max(-1, Math.Min(1, v1.Dot(v2))));
                avgAngle += angle;
            }

            avgAngle /= count;
            double curvaturePenalty = 1.0 - (avgAngle / Math.PI); // 0 = suave, 1 = agudo
            double adjusted = spacing * (1.0 - curvaturePenalty * factor);

            return Math.Max(min, adjusted);
        }

        private static bool HasSelfIntersection(Polyline poly)
        {
            var intersections = poly.GetIntersections(poly);
            return intersections.Count > 0;
        }
    }
}