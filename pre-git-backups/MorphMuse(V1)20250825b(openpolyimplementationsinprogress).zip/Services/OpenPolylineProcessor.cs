﻿using CamBam.CAD;
using CamBam.Geom;
using System.Collections.Generic;

namespace MorphMuse.Services
{
    internal class OpenPolylineProcessor
    {
        public List<Point3F> SimplifiedPoints { get; private set; }

        public OpenPolylineProcessor(Polyline openPolyline, double arcTolerance = 0.1, double simplifyTolerance = 0.5)
        {
            SimplifiedPoints = new List<Point3F>();

            if (openPolyline != null && !openPolyline.Closed)
            {
                // 1. Remove arcos convertendo para segmentos retos
                Polyline linearized = openPolyline.ToPolyline(arcTolerance);

                // 2. Extrai os pontos reais
                List<Point3F> originalPoints = new List<Point3F>();
                foreach (PolylineItem item in linearized.Points)
                {
                    originalPoints.Add(item.Point);
                }

                // 3. Aplica Douglas-Peucker
                SimplifiedPoints = PolylineSimplifier.DouglasPeucker(originalPoints, simplifyTolerance);
            }
        }

        public int Count => SimplifiedPoints.Count;
        public Point3F this[int index] => SimplifiedPoints[index];
    }
}