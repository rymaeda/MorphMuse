﻿using CamBam.CAD;
using CamBam.Geom;
using System.Collections.Generic;

namespace MorphMuse.Model
{
    internal class StlSurfaceBuilder
    {
        private Point3FArray _points;
        private List<TriangleFace> _faces;
        private Dictionary<Point3F, int> _pointIndexes;
        public Vector3F Front { get; set; } = new Vector3F(0, 0, 1); // padrão: para cima

        public StlSurfaceBuilder()
        {
            _points = new Point3FArray();
            _faces = new List<TriangleFace>();
            _pointIndexes = new Dictionary<Point3F, int>();
        }

        public void AddTriangle(Point3F a, Point3F b, Point3F c)
        {
            int ia = AddPoint(a);
            int ib = AddPoint(b);
            int ic = AddPoint(c);

            if (CorrectPermutation(a, b, c))
                _faces.Add(new TriangleFace(ia, ib, ic));
            else
                _faces.Add(new TriangleFace(ia, ic, ib));
        }

        public Surface Build()
        {
            Surface surface = new Surface();
            surface.Points = new Point3FArray(_points);
            surface.Faces = _faces.ToArray();
            return surface;
        }

        private int AddPoint(Point3F pt)
        {
            if (!_pointIndexes.TryGetValue(pt, out int index))
            {
                index = _points.Count;
                _points.Add(pt);
                _pointIndexes[pt] = index;
            }
            return index;
        }

        private bool CorrectPermutation(Point3F a, Point3F b, Point3F c)
        {
            double v = Vector3F.DotProduct(
                Vector3F.CrossProduct(new Vector3F(a, b), new Vector3F(a, c)),
                Front
            );
            return v > 0;
        }
    }
}