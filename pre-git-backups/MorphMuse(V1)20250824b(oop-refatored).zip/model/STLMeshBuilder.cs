﻿using CamBam.CAD;
using CamBam.Geom;
using System.Collections.Generic;

namespace MorphMuse.Model
{
    internal class Triangle
    {
        public Point3F A { get; set; }
        public Point3F B { get; set; }
        public Point3F C { get; set; }

        public Triangle(Point3F a, Point3F b, Point3F c)
        {
            A = a;
            B = b;
            C = c;
        }
    }

    internal class StlMeshBuilder
    {
        public static Mesh BuildMesh(List<Triangle> triangles)
        {
            Mesh mesh = new Mesh();

            foreach (var tri in triangles)
            {
                mesh.Faces.Add(new MeshFace(tri.A, tri.B, tri.C));
            }

            return mesh;
        }
    }
}