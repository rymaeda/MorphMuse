﻿using CamBam.CAD;
using CamBam.Geom;
using System.Collections.Generic;

namespace MorphMuse.Model
{
    internal class PointSamples
    {
        public List<Point3F> Points { get; private set; }

        public PointSamples(Polyline polyline)
        {
            Points = new List<Point3F>();

            if (polyline != null)
            {
                // Extrai os pontos da polilinha usando a API do CamBam
                PointList pointList = PointListUtils.CreatePointlistFromPolyline(polyline, 700);
                foreach (Point3F pt in pointList.Points)
                {
                    Points.Add(pt);
                }
            }
        }

        public int Count => Points.Count;

        public Point3F this[int index] => Points[index];
    }
}
