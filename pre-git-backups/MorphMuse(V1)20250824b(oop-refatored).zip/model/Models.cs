﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MorphMuse.model
{
    public class Point3D
    {
        public double X, Y, Z;
    }

    public class Triangle
    {
        public Point3D A, B, C;
    }

}
