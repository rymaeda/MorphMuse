﻿using CamBam.CAD;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MorphMuse.Services
{
    internal class ContourStacker
    {
        //public List<Polyline> GenerateContour(Polyline basePolyline, double stepHeight)
        //{
            // Cria offsets sucessivos para formar as camadas
        //}

    }
}
