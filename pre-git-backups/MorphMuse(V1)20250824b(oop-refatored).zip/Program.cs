﻿using CamBam.CAD;
using CamBam.Geom;
using CamBam.UI;
using CamBam.Util;
using MorphMuse;
using MorphMuse.Services;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace CambamPlugin
{
    public class Program
    {
        public static CamBamUI _ui;
        // This is the main entry point into the plugin.
        public static void InitPlugin(CamBamUI ui)
        {
            // Store a reference to the CamBamUI object passed to InitPlugin
            _ui = ui;

            // Create a new menu item in the top Plugins menu
            ToolStripMenuItem mi = new ToolStripMenuItem();
            mi.Text = "MorphMuse";
            mi.Click += new EventHandler(MorphMuse_Click);
            ui.Menus.mnuPlugins.DropDownItems.Add(mi);
        }

        static void MorphMuse_Click(object sender, EventArgs e)
        {
            ICADView view = _ui.ActiveView;
            try
            {
                if (PolylineManager.TryCreateFromSelection(out var manager))
                {
                    Layer layer;
                    if (!_ui.ActiveView.CADFile.HasLayer("BevelerTest"))
                    {
                        layer = _ui.ActiveView.CADFile.CreateLayer("BevelerTest");
                        layer.Color = Color.Fuchsia;
                    }
                    _ui.ActiveView.CADFile.SetActiveLayer("BevelerTest");
                    _ui.ActiveView.RefreshView();
                    Polyline[] offsetResult = manager.ClosedPoly.CreateOffsetPolyline(20.0, 0.01);
                    if (offsetResult != null && offsetResult.Length > 0)
                    {
                        Polyline offsetPoly = offsetResult[0];
                        _ui.ActiveView.CADFile.Add(offsetPoly);
                    }
                    for (int i = -9; i <= 9; i++)
                    {
                        if (i == 0) continue; // pula offset zero
                        double offsetValue = i * 2.0;
                        offsetResult = manager.ClosedPoly.CreateOffsetPolyline(offsetValue, 0.01);
                        if (offsetResult != null && offsetResult.Length > 0)
                        {
                            foreach (Polyline p in offsetResult)
                            {
                                _ui.ActiveView.CADFile.Add(p);
                            }
                        }
                    }


                    //CamBam.ThisApplication.AddLogMessage("DrawStreamline elapsed time:\t\t{0:G}\n", Interval.ToString());
                    _ui.ActiveView.ZoomToFit();
                }
            }
            catch (Exception errormessage)
            {
                MessageBox.Show(TextTranslation.Translate("Streamlines tracer Fatal Error\n") + errormessage);
                // close the form and exit
                return;
            }

        }
    }
}