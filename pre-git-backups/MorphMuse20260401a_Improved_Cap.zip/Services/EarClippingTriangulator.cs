using CamBam.Geom;
using System;
using System.Collections.Generic;

namespace MorphMuse.Services
{
    public static class EarClippingTriangulator
    {
        /// <summary>
        /// Triangula um polígono simples (pode ser côncavo) usando o algoritmo de Ear Clipping.
        /// Assume que todos os pontos estão no mesmo plano.
        /// </summary>
        public static List<TriangleFace> Triangulate(List<Point3F> polygon, Point3FArray points, Dictionary<Point3F, int> indexMap)
        {
            var faces = new List<TriangleFace>();
            if (polygon.Count < 3) return faces;

            // Criar uma lista de índices para trabalhar
            List<int> indices = new List<int>();
            for (int i = 0; i < polygon.Count; i++)
            {
                indices.Add(i);
            }

            // Determinar a orientação do polígono (sentido horário ou anti-horário)
            bool isClockwise = IsClockwise(polygon);

            int iterations = 0;
            while (indices.Count > 3 && iterations < 1000) // Guardrail para evitar loop infinito
            {
                bool earFound = false;
                for (int i = 0; i < indices.Count; i++)
                {
                    int prev = indices[(i - 1 + indices.Count) % indices.Count];
                    int curr = indices[i];
                    int next = indices[(i + 1) % indices.Count];

                    if (IsEar(prev, curr, next, indices, polygon, isClockwise))
                    {
                        // Adicionar o triângulo
                        int ia = Geometry3F.AddPoint(polygon[prev], points, indexMap);
                        int ib = Geometry3F.AddPoint(polygon[curr], points, indexMap);
                        int ic = Geometry3F.AddPoint(polygon[next], points, indexMap);
                        
                        // Orientação consistente
                        faces.Add(new TriangleFace(ia, ic, ib));

                        // Remover o vértice "orelha"
                        indices.RemoveAt(i);
                        earFound = true;
                        break;
                    }
                }

                if (!earFound) break; // Não encontrou mais orelhas (polígono possivelmente auto-interseccionado)
                iterations++;
            }

            // Adicionar o último triângulo restante
            if (indices.Count == 3)
            {
                int ia = Geometry3F.AddPoint(polygon[indices[0]], points, indexMap);
                int ib = Geometry3F.AddPoint(polygon[indices[1]], points, indexMap);
                int ic = Geometry3F.AddPoint(polygon[indices[2]], points, indexMap);
                faces.Add(new TriangleFace(ia, ic, ib));
            }

            return faces;
        }

        private static bool IsEar(int pIdx, int cIdx, int nIdx, List<int> indices, List<Point3F> polygon, bool isClockwise)
        {
            Point3F a = polygon[pIdx];
            Point3F b = polygon[cIdx];
            Point3F c = polygon[nIdx];

            // 1. Verificar se o ângulo é convexo
            if (!IsConvex(a, b, c, isClockwise)) return false;

            // 2. Verificar se algum outro ponto do polígono está dentro do triângulo (a, b, c)
            foreach (int idx in indices)
            {
                if (idx == pIdx || idx == cIdx || idx == nIdx) continue;
                if (IsPointInTriangle(polygon[idx], a, b, c)) return false;
            }

            return true;
        }

        private static bool IsConvex(Point3F a, Point3F b, Point3F c, bool isClockwise)
        {
            double crossProduct = (b.X - a.X) * (c.Y - b.Y) - (b.Y - a.Y) * (c.X - b.X);
            if (isClockwise) return crossProduct <= 0;
            return crossProduct >= 0;
        }

        private static bool IsClockwise(List<Point3F> polygon)
        {
            double area = 0;
            for (int i = 0; i < polygon.Count; i++)
            {
                Point3F p1 = polygon[i];
                Point3F p2 = polygon[(i + 1) % polygon.Count];
                area += (p2.X - p1.X) * (p2.Y + p1.Y);
            }
            return area > 0;
        }

        private static bool IsPointInTriangle(Point3F p, Point3F a, Point3F b, Point3F c)
        {
            double det = (b.Y - c.Y) * (a.X - c.X) + (c.X - b.X) * (a.Y - c.Y);
            double baryA = ((b.Y - c.Y) * (p.X - c.X) + (c.X - b.X) * (p.Y - c.Y)) / det;
            double baryB = ((c.Y - a.Y) * (p.X - c.X) + (a.X - c.X) * (p.Y - c.Y)) / det;
            double baryC = 1 - baryA - baryB;

            return baryA >= 0 && baryB >= 0 && baryC >= 0;
        }
    }
}
