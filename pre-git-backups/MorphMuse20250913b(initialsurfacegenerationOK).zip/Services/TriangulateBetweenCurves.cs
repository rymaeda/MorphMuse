﻿using CamBam.Geom;
using System.Collections.Generic;

namespace MorphMuse.Services
{
    public static class SurfaceBuilder
    {
        public static List<Triangle> TriangulateBetweenCurvesAdaptive(List<Point3F> lower, List<Point3F> upper)
        {
            List<Triangle> rawTriangles = new List<Triangle>();
            List<Triangle> finalTriangles = new List<Triangle>();

            int i = 0; // índice da curva inferior
            int j = 0; // índice da curva superior

            while (i < lower.Count - 1 && j < upper.Count - 1)
            {
                Point3F a = lower[i];
                Point3F b = upper[j];
                Point3F aNext = lower[i + 1];
                Point3F bNext = upper[j + 1];

                // Distâncias entre possíveis pares
                double dANextToB = Geometry3F.Distance(aNext, b);
                double dAtoBNext = Geometry3F.Distance(a, bNext);

                // Escolhe o triângulo com menor distorção
                if (dANextToB < dAtoBNext)
                {
                    rawTriangles.Add(new Triangle(a, b, aNext));
                    i++;
                }
                else
                {
                    rawTriangles.Add(new Triangle(a, b, bNext));
                    j++;
                }
            }

            // Finaliza segmentos restantes
            while (i < lower.Count - 1)
            {
                rawTriangles.Add(new Triangle(lower[i], upper[j], lower[i + 1]));
                i++;
            }

            while (j < upper.Count - 1)
            {
                rawTriangles.Add(new Triangle(lower[i], upper[j], upper[j + 1]));
                j++;
            }

            // Filtra degenerados e corrige invertidos
            foreach (var t in rawTriangles)
            {
                if (IsDegenerate(t)) continue;

                Triangle corrected = IsInverted(t) ? Invert(t) : t;
                finalTriangles.Add(corrected);
            }

            return finalTriangles;
        }

        public static bool IsDegenerate(Triangle t)
        {
            Vector3F ab = Geometry3F.FromPoints(t.A, t.B);
            Vector3F ac = Geometry3F.FromPoints(t.A, t.C);
            Vector3F cross = Geometry3F.Cross(ab, ac);
            double area = Geometry3F.Length(cross) * 0.5;

            return area < 1e-6; // tolerância ajustável
        }

        public static bool IsInverted(Triangle t)
        {
            Vector3F normal = Geometry3F.GetNormal(t.A, t.B, t.C);
            return normal.Z < 0; // critério: normal voltada para baixo
        }

        public static Triangle Invert(Triangle t)
        {
            return new Triangle(t.A, t.C, t.B);
        }
    }
}