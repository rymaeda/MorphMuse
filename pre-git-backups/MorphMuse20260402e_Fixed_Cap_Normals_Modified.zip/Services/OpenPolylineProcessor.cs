using CamBam.CAD;
using CamBam.Geom;
using System.Collections.Generic;

namespace MorphMuse.Services
{
    internal class OpenPolylineProcessor
    {
        public List<Point3F> SimplifiedPoints { get; private set; }

        public OpenPolylineProcessor(Polyline openPolyline, double arcTolerance, double simplifyTolerance)
        {
            //CheckOpenPolylineStart(openPolyline);
            SimplifiedPoints = new List<Point3F>();

            if (openPolyline != null && !openPolyline.Closed && openPolyline.Points.Count > 0)
            {
                // 1. Arcs removal
                Polyline linearized = openPolyline.RemoveArcs(arcTolerance);

                // 2. Define origin as first point (only for X, preserve absolute Y for height)
                Point3F origin = linearized.Points[0].Point;

                // 3. Extract and translate points: offset X to origin, preserve absolute Y (height) and Z
                List<Point3F> translatedPoints = new List<Point3F>();
                foreach (PolylineItem item in linearized.Points)
                {
                    Point3F pt = item.Point;
                    // Translate X to origin (for offset distances)
                    // Preserve absolute Y (for heights) and Z coordinates
                    Point3F relative = new Point3F(
                        pt.X - origin.X,  // Offset distance (relative to start)
                        pt.Y,             // Height (absolute value, NOT relative)
                        pt.Z              // Z coordinate (absolute value, NOT relative)
                    );
                    translatedPoints.Add(relative);
                }

                // 4. Apply Douglas-Peucker simplification
                SimplifiedPoints = PolylineSimplifier.SimplifyDouglasPeucker(translatedPoints, simplifyTolerance);
                
                // Log for debugging
                CamBam.ThisApplication.AddLogMessage($"OpenPolylineProcessor: Processed {SimplifiedPoints.Count} simplified points");
                foreach (var pt in SimplifiedPoints)
                {
                    CamBam.ThisApplication.AddLogMessage($"  Point: X={pt.X:F4}, Y={pt.Y:F4}, Z={pt.Z:F4}");
                }
            }
        }
    }
}
