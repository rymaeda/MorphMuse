﻿using CamBam.CAD;
using CamBam.UI;
using CamBam.Util;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MorphMuse.Services
{
    internal class PolylineManager
    {
        //public Polyline BasePolyline { get; private set; }
        //public Polyline ProfilePolyline { get; private set; }
        public Polyline ClosedPoly { get; private set; }
        public Polyline OpenPoly { get; private set; }
        public int CounterOpenP { get; private set; }
        public int CounterClosedP { get; private set; }

        private PolylineManager(Polyline closed, Polyline open)
        {
            ClosedPoly = closed;
            OpenPoly = open;
        }


        public static bool TryCreateFromSelection(out PolylineManager manager)
        {
            manager = null;
            ICADView view = CamBamUI.MainUI.ActiveView;

            if (view.SelectedEntities.Length == 0)
            {
                MessageBox.Show(TextTranslation.Translate("No selection."));
                return false;
            }

            Polyline closed = null;
            Polyline open = null;
            int closedCount = 0;
            int openCount = 0;

            foreach (Entity ent in view.SelectedEntities)
            {
                if (ent is Polyline poly)
                {
                    if (poly.Closed)
                    {
                        closed = poly;
                        closedCount++;
                    }
                    else
                    {
                        open = poly;
                        openCount++;
                    }
                }
            }

            if (closedCount == 1 && openCount == 1)
            {
                manager = new PolylineManager(closed, open)
                {
                    CounterClosedP = closedCount,
                    CounterOpenP = openCount
                };
                return true;
            }

            MessageBox.Show(TextTranslation.Translate(
                "Please, select one and just one closed Polyline and\none and just one open Polyline."));
            return false;
        }
    }
}
