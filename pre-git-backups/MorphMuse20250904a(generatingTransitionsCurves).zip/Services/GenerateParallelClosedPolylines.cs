﻿using CamBam.CAD;
using CamBam.Geom;
using System;
using System.Collections.Generic;

namespace MorphMuse.Services
{
    internal static class LayerGenerator
    {
        public static List<Polyline> GenerateParallelClosedPolylines(
            Polyline closedBase,
            List<Point3F> openReferencePoints)
        {
            var contours = new List<Polyline>();
            foreach (Point3F refPt in openReferencePoints)
            {
                float offsetValue = (float)refPt.X;
                float zHeight = (float)refPt.Y;

                // Uses a API's native method to generate parallel polyline
                Polyline[] offsetLayers = closedBase.CreateOffsetPolyline(offsetValue, 0.01f);
                if (offsetLayers == null || offsetLayers.Length == 0)
                {
                    CamBam.ThisApplication.AddLogMessage($"offsetValue: {offsetValue} // offsetLayers.Length: {(offsetLayers != null ? offsetLayers.Length.ToString() : "nulo")}");
                    continue;
                }
                foreach (Polyline layer in offsetLayers)
                {
                    // Apply Z height to all points
                    for (int i = 0; i < layer.Points.Count; i++)
                    {
                        PolylineItem item = layer.Points[i];// Get the current item
                        Point3F pt = item.Point;// Get current point
                        pt.Z = zHeight;// Set the new Z height
                        item.Point = pt;// Update the point with new Z
                        layer.Points[i] = item;// Update the point in the polyline
                    }

                    //layer.SetColor(System.Drawing.Color.MediumPurple);
                    contours.Add(layer);// Add the modified layer to the list
                }
            }
            return contours;
        }

        public static List<Point3F> InterpolateReferencePoints(List<Point3F> openReferencePoints, int resolution)
        {
            var interpolated = new List<Point3F>();

            for (int i = 0; i < openReferencePoints.Count - 1; i++)
            {
                Point3F a = openReferencePoints[i];
                Point3F b = openReferencePoints[i + 1];

                for (int j = 0; j <= resolution; j++)
                {
                    float t = j / (float)resolution;
                    float x = (float)(a.X + t * (b.X - a.X));
                    float y = (float)(a.Y + t * (b.Y - a.Y));
                    float z = (float)(a.Z + t * (b.Z - a.Z));

                    interpolated.Add(new Point3F(x, y, z));
                }
            }

            return interpolated;
        }

        public static List<Polyline> DetectTransitionsFromInterpolatedPoints(
        Polyline closedBase,
        List<Point3F> openReferencePoints,
        int resolution,
        float tolerance = 0.001f)
        {
            var contours = new List<Polyline>();
            var interpolated = InterpolateReferencePoints(openReferencePoints, resolution);

            int? previousCount = null;
            var orderedContours = new SortedDictionary<float, List<Polyline>>();

            foreach (var refPt in interpolated)
            {
                var curves = GenerateParallelClosedPolylines(closedBase, new List<Point3F> { refPt });
                int currentCount = curves.Count;

                if (previousCount.HasValue && currentCount != previousCount.Value)
                {
                    orderedContours[(float)refPt.Y] = curves;
                    CamBam.ThisApplication.AddLogMessage($"Transição detectada em Z={refPt.Y:F3}: {previousCount} → {currentCount}");
                }

                previousCount = currentCount;
            }

            foreach (var kvp in orderedContours)
            {
                contours.AddRange(kvp.Value);
            }

            return contours;
        }

    public static List<Polyline> GenerateAdaptiveContoursFull(
    Polyline closedBase,
    List<Point3F> openReferencePoints,
    int interpolationResolution = 20,
    float tolerance = 0.001f)
        {
            var contours = new List<Polyline>();
            var orderedContours = new SortedDictionary<float, List<Polyline>>();

            // 1. Gera curvas nos nós originais
            foreach (var refPt in openReferencePoints)
            {
                var curves = GenerateParallelClosedPolylines(closedBase, new List<Point3F> { refPt });
                if (curves.Count > 0)
                    orderedContours[(float)refPt.Y] = curves;
            }

            // 2. Interpola pontos intermediários
            var interpolatedPoints = InterpolateReferencePoints(openReferencePoints, interpolationResolution);

            int? previousCount = null;
            foreach (var refPt in interpolatedPoints)
            {
                var curves = GenerateParallelClosedPolylines(closedBase, new List<Point3F> { refPt });
                int currentCount = curves.Count;

                if (previousCount.HasValue && currentCount != previousCount.Value)
                {
                    if (!orderedContours.ContainsKey((float)refPt.Y))
                        orderedContours[(float)refPt.Y] = curves;

                    CamBam.ThisApplication.AddLogMessage($"Transição detectada em Z={refPt.Y:F3}: {previousCount} → {currentCount}");
                }

                previousCount = currentCount;
            }

            // 3. Junta tudo em ordem
            foreach (var kvp in orderedContours)
            {
                contours.AddRange(kvp.Value);
            }

            return contours;
        }
    }
}