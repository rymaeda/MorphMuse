﻿using CamBam.Geom;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MorphMuse.Services
{
    public static class Geometry3F
    {
        public static Point3F Subtract(Point3F a, Point3F b)
        {
            return new Point3F(a.X - b.X, a.Y - b.Y, a.Z - b.Z);
        }

        public static Point3F Cross(Point3F a, Point3F b)
        {
            return new Point3F(
                a.Y * b.Z - a.Z * b.Y,
                a.Z * b.X - a.X * b.Z,
                a.X * b.Y - a.Y * b.X
            );
        }

        public static float Dot(Point3F a, Point3F b)
        {
            return (float)(a.X * b.X + a.Y * b.Y + a.Z * b.Z);
        }

        public static float Length(Point3F v)
        {
            return (float)Math.Sqrt(v.X * v.X + v.Y * v.Y + v.Z * v.Z);
        }

        public static float Distance(Point3F a, Point3F b)
        {
            return Length(Subtract(a, b));
        }

        public static float PerpendicularDistance(Point3F p, Point3F a, Point3F b)
        {
            Point3F ab = Subtract(b, a);
            Point3F ap = Subtract(p, a);
            Point3F cross = Cross(ab, ap);
            float area = Length(cross);
            float baseLength = Length(ab);
            return baseLength == 0 ? 0 : area / baseLength;
        }

        public static Point3F Normalize(Point3F v)
        {
            float len = Length(v);
            return len == 0 ? new Point3F(0, 0, 0) : new Point3F(v.X / len, v.Y / len, v.Z / len);
        }

        public static Point3F Add(Point3F a, Point3F b)
        {
            return new Point3F(a.X + b.X, a.Y + b.Y, a.Z + b.Z);
        }

        public static Point3F Scale(Point3F v, float factor)
        {
            return new Point3F(v.X * factor, v.Y * factor, v.Z * factor);
        }
    }
}