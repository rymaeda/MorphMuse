[](https://cambamcnc.com/cdn-cgi/content?id=VIwgfPYOJkPfZgc9ZdvsGfMMd3iyn3NDgMcI7lxFlm8-1775270244.8683388-1.0.1.1-z85hUORxWqZ0HjcPiFGvpt5DWqPbAcuFXXRxtAPc42Q)

# [](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&)

[Home](https://cambamcnc.com) [Downloads](https://cambamcnc.com/downloads) [Forum](https://cambamcnc.com/forum) [Shop](https://cambamcnc.com/shop)

## News:

  
* [Home](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&)
* [Help](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=help)
* [Search](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=search)
* 
* 

* [CamBam](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&) »
* [Resources](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&) »
* [Scripts and Plugins](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&board=6.0) »
* [Add Points ( Node Editing ) To Polylines](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&topic=4855.0)

[« previous](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&topic=4855.0;prev_next=prev) [next »](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&topic=4855.0;prev_next=next)

* [Print](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=printpage;topic=4855.0)

Pages: [1](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&topic=4855.0) [2](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&topic=4855.15) [3](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&topic=4855.30) [ **4** ] [5](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&topic=4855.60) [6](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&topic=4855.75)

### Author Topic: Add Points ( Node Editing ) To Polylines  (Read 86597 times)

#### [dh42](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=1333 "View the profile of dh42")

* Administrator
* CNC Jedi
* 
* [](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=1333)
* Posts: 7635
* + [](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=1333)
    + [](http://www.atelier-des-fougeres.fr/Cambam/Aide_V1/Contents.htm "Cambam V1.0 French Doc")

##### [Re: Add Points ( Node Editing ) To Polylines](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&topic=4855.msg36748)

« **Reply #45 on:** April 27, 2015, 20:13:22 pm »

do a toolbar instead a menu  
  
\++  
David

Logged

* * *

#### [EddyCurrent](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=6583 "View the profile of EddyCurrent")

* CNC Jedi
* 
* [](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=6583)
* Posts: 5338
* Made in England
* + [](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=6583)

##### [Re: Add Points ( Node Editing ) To Polylines](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&topic=4855.msg36750)

« **Reply #46 on:** April 27, 2015, 20:32:52 pm »

Maybe as well as  
  
I've just discovered it's the context menu code that is causing the problem. If I comment that part out the normal menus work.  
  
Edit: You can't use the same ToolStripMenuItem in both places.  
So in the context menu I have  
ToolStripMenuItem Polyadd = new ToolStripMenuItem();  
  
and in the Edit menu I have  
ToolStripMenuItem Polyadd2 = new ToolStripMenuItem();  
  
and both use the same event handler.  
  
But it will have to wait until tomorrow now.

« _Last Edit: April 27, 2015, 20:39:07 pm by EddyCurrent_ »

Logged

Filmed in Supermarionation

* * *

#### [dh42](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=1333 "View the profile of dh42")

* Administrator
* CNC Jedi
* 
* [](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=1333)
* Posts: 7635
* + [](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=1333)
    + [](http://www.atelier-des-fougeres.fr/Cambam/Aide_V1/Contents.htm "Cambam V1.0 French Doc")

##### [Re: Add Points ( Node Editing ) To Polylines](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&topic=4855.msg36751)

« **Reply #47 on:** April 27, 2015, 21:00:03 pm »

Quote

> Edit: You can't use the same ToolStripMenuItem in both places.
  
Hum yes, it reminds me something, ... I think I had the same problem with the nummove plugin ...  
  
It's a very very useful tool this plugin .. I like it  
  
For the toolbar, Maybe I'll try to add one in the next plugin in progress, and if I find how to do, I'll do a toolbar that handle the other "line utile" plugins that exists..  
  
I'm working on a radius plugin that will work as SolidWorks, you just click on the nodes you want to round on a polyline, with a small windows where you can change the radius/chamfer value without exiting the edit mode.(If I can mix an EditMode and a custom form ... not sure)  
  
Currently my "radius" routine works well, even on arc/arc or arc/line ... (and without Math/geometry ) ... and I will certainly use the skeleton of your edit mode to do the node select.  
  
\++  
David

Logged

* * *

#### [EddyCurrent](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=6583 "View the profile of EddyCurrent")

* CNC Jedi
* 
* [](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=6583)
* Posts: 5338
* Made in England
* + [](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=6583)

##### [Re: Add Points ( Node Editing ) To Polylines](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&topic=4855.msg36752)

« **Reply #48 on:** April 27, 2015, 21:12:03 pm »

I lied about waiting until tomorrow, could not put it down until complete.  
  
I think all the points raised in this thread have been covered now, other than the undo stack (if it gets done )  
  
So new version 4 attached here; <http://www.cambam.co.uk/forum/index.php?topic=4855.msg36669>  
and I hope it's the final version.  
  
Tomorrow - onto the next one

« _Last Edit: April 27, 2015, 21:15:12 pm by EddyCurrent_ »

Logged

Filmed in Supermarionation

* * *

#### [dh42](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=1333 "View the profile of dh42")

* Administrator
* CNC Jedi
* 
* [](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=1333)
* Posts: 7635
* + [](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=1333)
    + [](http://www.atelier-des-fougeres.fr/Cambam/Aide_V1/Contents.htm "Cambam V1.0 French Doc")

##### [Re: Add Points ( Node Editing ) To Polylines](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&topic=4855.msg36753)

« **Reply #49 on:** April 27, 2015, 21:22:12 pm »

Ah, the undo is easy to do ; before entering in the edit mode, just add this two lines  
  
'create a undo point for the active layer  
**CamBamUI.MainUI.UndoBuffer.AddUndoPoint("MyUndoPoint")**  
  
'add the entities of the active layer in the ubdo buffer  
**CamBamUI.MainUI.UndoBuffer.Add(CamBamUI.MainUI.ActiveView.CADFile.ActiveLayer.Entities)**  
  
then, after exiting the edit mode, if you undo, the polyline return to it's state before editing  
  
\++  
David

Logged

* * *

#### [EddyCurrent](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=6583 "View the profile of EddyCurrent")

* CNC Jedi
* 
* [](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=6583)
* Posts: 5338
* Made in England
* + [](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=6583)

##### [Re: Add Points ( Node Editing ) To Polylines](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&topic=4855.msg36760)

« **Reply #50 on:** April 28, 2015, 09:13:19 am »

Okay I added that to the start.  
  
I also read some threads by Andy, the undo feature could be added to each point etc. but having tried that today I'm not getting much success. It's going to be one of those I'll have to revisit some time.  
  
Updated version 5 added here; <http://www.cambam.co.uk/forum/index.php?topic=4855.msg36669>

Logged

Filmed in Supermarionation

* * *

#### [dh42](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=1333 "View the profile of dh42")

* Administrator
* CNC Jedi
* 
* [](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=1333)
* Posts: 7635
* + [](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=1333)
    + [](http://www.atelier-des-fougeres.fr/Cambam/Aide_V1/Contents.htm "Cambam V1.0 French Doc")

##### [Re: Add Points ( Node Editing ) To Polylines](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&topic=4855.msg36764)

« **Reply #51 on:** April 28, 2015, 13:24:22 pm »

Hello,  
  
Maybe it's not the best undo method that I give to you , because it store data for all the entities on the active layer ; I use it when I create a new entity. If the entity already exists, you can undo only the related entity.  
  
Ex, in my NumMove plugin, the entities are only moved or rotated, no creation or deletion, then I use.  
  
**CamBamUI.MainUI.UndoBuffer.AddUndoPoint("MyUndoPoint")**  
  
then for each entity (ent) in the selection to process I use  
  
**CamBamUI.MainUI.UndoBuffer.Add(ent)**  
  
I think that if you want to add a undo for each point added/removed you need to use both line above for each point ... but that only undo the polyline, you need also to undo your internal data ... more complicated.  
  
\++  
David

Logged

* * *

#### [dh42](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=1333 "View the profile of dh42")

* Administrator
* CNC Jedi
* 
* [](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=1333)
* Posts: 7635
* + [](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=1333)
    + [](http://www.atelier-des-fougeres.fr/Cambam/Aide_V1/Contents.htm "Cambam V1.0 French Doc")

##### [Re: Add Points ( Node Editing ) To Polylines](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&topic=4855.msg36765)

« **Reply #52 on:** April 28, 2015, 13:33:49 pm »

Hum, the Undo don't works for me ..  
  
try this  
  
\- create a polyline  
\- use the plugin to add 2 new points and esc  
\- edit the polyline, it contain the 2 new points -> Ok  
\- do a undo  
\- edit the polyline ; the 2 new points are always here.-> Undo not works ...  
  
\++  
David

Logged

* * *

#### [EddyCurrent](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=6583 "View the profile of EddyCurrent")

* CNC Jedi
* 
* [](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=6583)
* Posts: 5338
* Made in England
* + [](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=6583)

##### [Re: Add Points ( Node Editing ) To Polylines](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&topic=4855.msg36766)

« **Reply #53 on:** April 28, 2015, 13:35:23 pm »

I realize now that the code should be structured in a way that undo can work smoothly, I think I have not done it that way.

Logged

Filmed in Supermarionation

* * *

#### [dh42](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=1333 "View the profile of dh42")

* Administrator
* CNC Jedi
* 
* [](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=1333)
* Posts: 7635
* + [](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=1333)
    + [](http://www.atelier-des-fougeres.fr/Cambam/Aide_V1/Contents.htm "Cambam V1.0 French Doc")

##### [Re: Add Points ( Node Editing ) To Polylines](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&topic=4855.msg36767)

« **Reply #54 on:** April 28, 2015, 13:53:26 pm »

Ah ah, works with that.  
  
Code: [[Select]](javascript:void\(0\);)

`public void MyMain()  
        {  
          if (view.SelectedEntities.Length != 1) { MessageBox.Show(TextTranslation.Translate("Please Select One Item Only")); }  
            else  
            {  
                foreach (Entity ent in view.SelectedEntities)  
                {  
                    if (ent is Polyline && !(ent is PolyRectangle))  
                    {  
                        CamBamUI.MainUI.UndoBuffer.AddUndoPoint("Poly Add Points");  
                        CamBamUI.MainUI.UndoBuffer.Add(ent);  
  
                        // get ID of selected polyline, this to check if it changes by deselecting the line  
                        polyid = ent.ID;  
                        // get current state of user setting 'Snap To objects'  
                        SnapToPoints_State = CamBam.CamBamConfig.Defaults.SnapToPoints;  
                         
                        // set state to 'true' it helps a lot with cursor placement for deleting points  
                        if (CamBam.CamBamConfig.Defaults.SnapToPoints == false) { CamBam.CamBamConfig.Defaults.SnapToPoints = true; }  
                           
  
                        DisplayExistingPoints();  
                        InsertAPoint();  
                    }  
                    else { MessageBox.Show(TextTranslation.Translate("Polylines Only ! - Please Convert to Polylines and try again")); }  
                }  
            }  
        }`

Logged

* * *

#### [dh42](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=1333 "View the profile of dh42")

* Administrator
* CNC Jedi
* 
* [](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=1333)
* Posts: 7635
* + [](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=1333)
    + [](http://www.atelier-des-fougeres.fr/Cambam/Aide_V1/Contents.htm "Cambam V1.0 French Doc")

##### [Re: Add Points ( Node Editing ) To Polylines](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&topic=4855.msg36768)

« **Reply #55 on:** April 28, 2015, 14:00:49 pm »

If I use the undo during add point, It works too, the points are removed, we can continue to add new points, the only thing is that the small squares for the undoed points don't disappears ... maybe if it's possible you need to disable the ability to click the undo during editing ...  
  
\++  
David

Logged

* * *

#### [EddyCurrent](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=6583 "View the profile of EddyCurrent")

* CNC Jedi
* 
* [](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=6583)
* Posts: 5338
* Made in England
* + [](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=6583)

##### [Re: Add Points ( Node Editing ) To Polylines](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&topic=4855.msg36769)

« **Reply #56 on:** April 28, 2015, 14:21:24 pm »

David,  
I can see you want to get this working  
  
I put an undo here;  
  
// is clicked point within 3 pixel distance ?  
// need to check here because measured distance changes if zoom is used.  
GetPixelDistance();  
  
CamBamUI.MainUI.UndoBuffer.AddUndoPoint("Insert Point");  
CamBamUI.MainUI.UndoBuffer.Add(nearpoly);  
  
if (tempvect.Length < PixelDistance)  
{  
  
What you have to do is hit Esc to come out of the plugin edit mode, double click the line to enter the CamBam Polyline edit mode, this will show the square boxes. Now if you use Ctrl Z the points will undo one at a time.  
  
The squares don't disappear because Temp\_pointlist will not add to the undo buffer, that's becasue it's a type Pointlist2 that I created.  
  
With the code above it's possible to press Ctr+Z and think nothing has happened, but you have done an 'undo' at each press.  
If I could disable the undo keys while the plugin was running I think it would be okay to leave the undo until using  CamBam's Polyline Edit mode, and it works good like that with the code above.  
  
How to disable the undo

« _Last Edit: April 28, 2015, 15:52:04 pm by EddyCurrent_ »

Logged

Filmed in Supermarionation

* * *

#### [dh42](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=1333 "View the profile of dh42")

* Administrator
* CNC Jedi
* 
* [](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=1333)
* Posts: 7635
* + [](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=1333)
    + [](http://www.atelier-des-fougeres.fr/Cambam/Aide_V1/Contents.htm "Cambam V1.0 French Doc")

##### [Re: Add Points ( Node Editing ) To Polylines](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&topic=4855.msg36771)

« **Reply #57 on:** April 28, 2015, 16:32:53 pm »

Quote

> How to disable the undo
  
good question .... maybe the toolbar icon itself can be disabled ...(ghosted) ?  
  
EDIT: and the menu too, because the shortkey is attached to the menu  
  
I tried a SuspendEvents ... but with no luck  
<http://www.cambam.co.uk/forum/index.php?topic=431.0>  
  
I just redo your editmode in VB (plugin), and with a form in addition ; good news, I can change a value on the form that stay opened (a num entry) without disturb the editmode ...  
  
\++  
David

« _Last Edit: April 28, 2015, 16:41:38 pm by dh42_ »

Logged

* * *

#### [dh42](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=1333 "View the profile of dh42")

* Administrator
* CNC Jedi
* 
* [](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=1333)
* Posts: 7635
* + [](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=1333)
    + [](http://www.atelier-des-fougeres.fr/Cambam/Aide_V1/Contents.htm "Cambam V1.0 French Doc")

##### [Re: Add Points ( Node Editing ) To Polylines](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&topic=4855.msg36777)

« **Reply #58 on:** April 28, 2015, 18:03:20 pm »

Re  
  
I find how to disable menu and toolbar.  
  
Disable menu  
**CamBam.ThisApplication.TopWindow.MainMenuStrip.Enabled = False**  
  
And of course True to enable  
  
For the toolbar it's a little more complicated.  
  
To disable.  
  
**Dim c As Control  
  
'disable toolbar  
For Each c In CamBam.ThisApplication.TopWindow.Controls  
If c.Name = "toolStripContainer1" Then  
c.Controls.Item(3).Enabled = False  
Exit For  
End If  
Next  
  
' do your job  
  
'and enable  
  
c.Controls.Item(3).Enabled = True**  
  
\++  
David

« _Last Edit: April 28, 2015, 21:45:55 pm by dh42_ »

Logged

* * *

#### [EddyCurrent](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=6583 "View the profile of EddyCurrent")

* CNC Jedi
* 
* [](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=6583)
* Posts: 5338
* Made in England
* + [](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=profile;u=6583)

##### [Re: Add Points ( Node Editing ) To Polylines](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&topic=4855.msg36782)

« **Reply #59 on:** April 28, 2015, 19:14:28 pm »

It's good stuff you found David but I can't help thinking it's going in a wrong direction for this plugin.  
There must be a more friendly way ?  
  
For example if I change Temp\_pointlist to an normal pointlist and add it to the undo buffer, everything works as it should but the little squares are not drawn, just the small dots of a pointlist.

« _Last Edit: April 28, 2015, 20:53:47 pm by EddyCurrent_ »

Logged

Filmed in Supermarionation

* * *

* [Print](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&action=printpage;topic=4855.0)

Pages: [1](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&topic=4855.0) [2](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&topic=4855.15) [3](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&topic=4855.30) [ **4** ] [5](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&topic=4855.60) [6](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&topic=4855.75)

[« previous](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&topic=4855.0;prev_next=prev) [next »](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&topic=4855.0;prev_next=next)

* [CamBam](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&) »
* [Resources](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&) »
* [Scripts and Plugins](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&board=6.0) »
* [Add Points ( Node Editing ) To Polylines](https://cambamcnc.com/forum/index.php?PHPSESSID=fo75feb4s9b9di95qqo9karko0&topic=4855.0)

  [Simple Audio Video Embedder](http://www.createaforum.com)

Page created in 0.155 seconds with 21 queries.