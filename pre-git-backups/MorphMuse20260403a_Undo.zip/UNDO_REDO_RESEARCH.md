# CamBam Undo/Redo Implementation Research

## Key Findings

### CADFile Class Methods
From the CamBam API documentation, the `CADFile` class provides:

1. **Add Methods** - Add entities to the drawing
   - `void Add(Entity entity)` - Add entity to active layer
   - `void Add(Entity entity, Layer layer)` - Add entity to specific layer
   - `void Add(List<Entity> entities)` - Add multiple entities

2. **Remove Methods** - Remove entities from the drawing
   - `void RemovePrimitive(Entity entity)` - Remove a primitive
   - `void RemovePrimitives(List<Entity> entities)` - Remove multiple primitives
   - `void RemovePrimitiveID(int ID)` - Remove by ID

3. **Event Methods** - Fire events for undo/redo
   - `void FireBeforeEntitiesAddedEvent(Entity entity)`
   - `void FireAfterEntitiesAddedEvent(Entity entity)`
   - `void FireBeforeEntitiesRemovedEvent(Entity entity)`
   - `void FireAfterEntitiesRemovedEvent(Entity entity)`

4. **Modification Methods**
   - `void OnModified()` - Triggers DocumentModified event and marks drawing as modified
   - `bool HasChanges()` - Check if drawing has unsaved changes

### CamBamUI Class
The `CamBamUI` class provides access to:
- `ActiveView` - Current view/document
- `ActiveView.CADFile` - Current drawing file

## Undo/Redo Strategy for MorphMuse

The CamBam API automatically tracks undo/redo when:
1. Entities are added via `CADFile.Add()`
2. Entities are removed via `CADFile.RemovePrimitive()`
3. Events are properly fired

### Implementation Approach

1. **Wrap operations in transaction-like behavior**
   - Disable events during bulk operations: `SuspendEvents = true`
   - Perform all modifications
   - Re-enable events: `SuspendEvents = false`
   - Fire appropriate events to trigger undo recording

2. **Use OnModified() to mark changes**
   - Call after all entities are added
   - Ensures CamBam records the operation in undo history

3. **Provide meaningful operation names**
   - CamBam shows "Undo [OperationName]" in UI
   - Need to investigate how to set operation name

## Notes

- CamBam 0.9.8 added Undo/Redo buttons to toolbar
- Undo/Redo system is built-in and automatic
- Plugins should leverage existing system rather than implement custom undo
- The key is using proper API methods and firing events correctly
