﻿using CamBam.CAD;
using CamBam.UI;
using CamBam.Geom;
using System.Collections.Generic;

public static class CurveVisualizer
{
    private static CamBamUI _ui = CamBamUI.MainUI;

    public static void VisualizeSampledCurves(List<List<Point3F>> sampledCurves, string layerPrefix = "Curva_")
    {
        CADFile cadFile = _ui.ActiveView.CADFile;

        for (int i = 0; i < sampledCurves.Count; i++)
        {
            List<Point3F> curvePoints = sampledCurves[i];
            Polyline poly = new Polyline();

            for (int j = 0; j < curvePoints.Count; j++)
            {
                poly.Add(curvePoints[j]);
            }

            poly.Closed = false;

            // Cria e ativa uma nova camada única
            string layerName = CreateUniqueLayer(layerPrefix);
            cadFile.SetActiveLayer(layerName);

            // Adiciona a entidade à camada ativa
            cadFile.Add(poly);
        }
    }

    private static string CreateUniqueLayer(string baseName)
    {
        int index = 1;
        string layerName;

        do
        {
            layerName = $"{baseName}{index:D4}";
            index++;
        }
        while (_ui.ActiveView.CADFile.HasLayer(layerName));

        _ui.ActiveView.CADFile.CreateLayer(layerName);
        _ui.ActiveView.CADFile.SetActiveLayer(layerName);

        return layerName;
    }
}