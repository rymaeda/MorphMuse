﻿using CamBam.CAD;
using CamBam.Geom;
using CamBam.UI;
using System.Collections.Generic;

public static class TriangleVisualizer
{
    private static CamBamUI _ui = CamBamUI.MainUI;
    public static void VisualizeTriangles(List<Triangle> triangles, string layerName, CamBamUI ui)
    {
        if (!ui.ActiveView.CADFile.HasLayer(layerName))
            ui.ActiveView.CADFile.CreateLayer(layerName);

        Layer layer = ui.ActiveView.CADFile.Layers[layerName];

        foreach (var tri in triangles)
        {
            if (tri == null) continue;

            Polyline poly = new Polyline();
            poly.Add(tri.A);
            poly.Add(tri.B);
            poly.Add(tri.C);
            poly.Closed = true;

            //layer.Add(poly);
            ui.ActiveView.CADFile.Add(poly);
        }
    }
    public static void VisualizeTrianglesX(List<Triangle> triangles, string layerName)
    {
        CADFile cadFile = _ui.ActiveView.CADFile;

        // Cria camada se necessário
        if (!cadFile.HasLayer(layerName))
        {
            cadFile.CreateLayer(layerName);
        }

        cadFile.SetActiveLayer(layerName);

        for (int i = 0; i < triangles.Count; i++)
        {
            Triangle t = triangles[i];

            if (t == null || t.A == null || t.B == null || t.C == null)
                continue;

            Polyline tri = new Polyline();
            tri.Add(t.A);
            tri.Add(t.B);
            tri.Add(t.C);
            tri.Closed = true;

            cadFile.Add(tri);
        }
    }
}