# MorphMuse Plugin - Using Two Open Curves

## Quick Start

The MorphMuse plugin now supports generating sweep surfaces from **two open curves**. This guide explains how to use this new feature.

## What You Can Do Now

Previously, MorphMuse required:
- **One closed curve** (the path to be offset)
- **One open curve** (the profile defining offsets and heights)

Now you can also use:
- **Two open curves** (one as the path, one as the profile)

This is useful for creating surfaces that sweep along an open path, such as:
- Ribbon-like surfaces
- Tapered tubes or channels
- Morphing surfaces between two open profiles

## Step-by-Step Instructions

### 1. Prepare Your Curves

Create or import two open curves in CamBam:
- **Rail Curve:** The path along which the surface will sweep
- **Form Curve:** The profile that defines how the rail curve will be offset and elevated

**Example:**
- Rail: A curved path (like a river's path viewed from above)
- Form: A curve showing the cross-section profile (e.g., width and height variations along the rail)

### 2. Select Both Curves

In CamBam's drawing view:
1. Click on the first curve to select it
2. Hold **Ctrl** and click on the second curve to add it to the selection
3. Both curves should now be highlighted

### 3. Invoke the Plugin

From the CamBam menu:
1. Go to **Plugins** → **MorphMuse**
2. The plugin will analyze your selection

### 4. Disambiguate the Curves (New Dialog)

If you selected two open curves, a dialog box will appear:

```
┌─────────────────────────────────────┐
│ Select Rail and Form Curves         │
├─────────────────────────────────────┤
│ Rail Curve:      [Dropdown ▼]       │
│ Form Curve:      [Dropdown ▼]       │
│                                     │
│          [OK]        [Cancel]       │
└─────────────────────────────────────┘
```

**What to do:**
- **Rail Curve:** Select the curve that represents the **path** (the direction along which the surface will sweep)
- **Form Curve:** Select the curve that represents the **profile** (the cross-section that defines offsets and heights)

**Example:**
- If you have a curved path and a height profile, select the path as Rail and the profile as Form

### 5. Review the Generated Surface

Once you click **OK**, the plugin will:
1. Process the form curve to extract offset and height information
2. Generate offset curves along the rail curve
3. Create a triangulated surface connecting these offset curves
4. Add the surface to your drawing in a new layer called "MorphSurface"

The surface will be displayed in **deep sky blue** color.

## Understanding the Form Curve

The form curve's **X and Y coordinates** have special meanings:

| Coordinate | Meaning | Example |
|------------|---------|---------|
| **X** | Offset distance from the rail curve | 0 = on the rail, 5 = 5 units away |
| **Y** | Height (Z coordinate) of the surface | 0 = base level, 10 = 10 units up |

**Example Form Curve:**
```
Y (Height)
^
|     /\
|    /  \
|   /    \
|  /      \
| /________\_____ X (Offset)
0    5    10
```

This form curve would create a surface that:
- Starts at the rail curve (X=0) at height 0
- Expands to 5 units offset at height 5
- Expands to 10 units offset at height 10
- Returns to the rail curve (X=0) at height 0

## Tips and Best Practices

### Curve Orientation
- The **rail curve** should be a smooth path without sharp kinks (or at least fewer kinks than the form curve)
- The **form curve** should start and end at or near X=0 (on the rail curve) for a closed surface

### Offset Distances
- Positive X values in the form curve create outward offsets
- Negative X values create inward offsets
- The plugin will skip any offset that cannot be computed (e.g., if the offset distance is too large)

### Height Variation
- Use Y values in the form curve to create height variation along the rail
- A flat form curve (constant Y) creates a surface at a uniform height

### Surface Quality
- Use curves with sufficient points for smooth results
- Very coarse curves may produce faceted surfaces
- Very fine curves may take longer to process

## Troubleshooting

### "Invalid Selection" Message
**Problem:** You see "Invalid Selection. Please select one open and one closed polyline, or two open polylines."

**Solution:** Make sure you have selected exactly two open curves (or one open and one closed). Check that:
- Both curves are actually open (not closed loops)
- You have selected exactly two curves (not one, not three)

### Dialog Doesn't Appear
**Problem:** The curve selection dialog doesn't appear after selecting two open curves.

**Solution:** 
- Verify that both curves are recognized as open polylines
- Try converting curves to polylines first (if they are splines or other types)
- Check the CamBam log for error messages

### Surface Not Generated
**Problem:** The plugin runs but no surface appears.

**Solution:**
- Check that the form curve has at least 2 points (to define at least one offset)
- Verify that the offsets are valid (not too large relative to the rail curve)
- Check the CamBam log for messages about skipped offsets

### Surface Looks Wrong
**Problem:** The generated surface is twisted, self-intersecting, or otherwise incorrect.

**Solution:**
- Verify that the form curve starts and ends near X=0
- Check that X values in the form curve are reasonable (not too large)
- Try simplifying the curves (fewer points) to see if the issue is related to curve complexity
- Ensure the rail curve is smooth and doesn't have sharp reversals

## Comparison: Closed vs. Two Open

| Aspect | Closed + Open | Two Open |
|--------|---------------|----------|
| **Input** | 1 closed curve + 1 open curve | 2 open curves |
| **Dialog** | None (roles are clear) | Yes (to select rail and form) |
| **Surface Type** | Closed tube/container | Open ribbon/channel |
| **Cap** | Yes (top is closed) | No (both ends are open) |
| **Use Case** | Vases, containers, enclosed shapes | Ribbons, channels, open surfaces |

## Advanced: Understanding the Algorithm

The plugin works as follows:

1. **Extract Profile:** The form curve is analyzed to extract points representing (offset, height) pairs
2. **Generate Sections:** For each point in the form curve, an offset of the rail curve is created at the specified distance and elevated to the specified height
3. **Triangulate:** Consecutive offset curves are connected with triangles to form a continuous surface
4. **Output:** The triangulated surface is added to the drawing

This process is similar to the "sweep" operation in many 3D modeling tools, but adapted for 2D curves in CamBam.

## Getting Help

If you encounter issues or have questions:
1. Check the CamBam log for error messages (View → Log)
2. Review this guide and the examples
3. Experiment with simple test curves to understand the behavior
4. Contact the plugin developer with details about your curves and the error message

## Examples

### Example 1: Simple Ribbon
- **Rail:** A curved path (like a sine wave)
- **Form:** A simple rectangle (e.g., from X=0 to X=2, Y from 0 to 1 and back to 0)
- **Result:** A ribbon-like surface following the curved path

### Example 2: Tapered Channel
- **Rail:** A straight or curved path
- **Form:** A triangle (e.g., X from 0 to 2 and back to 0, Y from 0 to 3 and back to 0)
- **Result:** A tapered channel that widens in the middle and narrows at the ends

### Example 3: Variable Height Ribbon
- **Rail:** A curved path
- **Form:** A curve that varies in both X (width) and Y (height)
- **Result:** A surface that changes both width and height along the rail

## Conclusion

The two-open-curves feature extends MorphMuse's capabilities to handle more complex sweep scenarios. By providing an interactive dialog to disambiguate curve roles, the plugin ensures a smooth and intuitive user experience.

Experiment with different curve combinations to discover the creative possibilities!
