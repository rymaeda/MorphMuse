# CurveSelectionDialog - Improvements Documentation

## Overview

The `CurveSelectionDialog` has been redesigned to provide a simple, clear interface for selecting which of the two open curves should be the Rail (path to be offset) and which should be the Form (profile definition). The dialog displays curve identification using CamBam API best practices and employs a single radio-button selection for intuitive disambiguation.

## Design Philosophy

**Single Selection Pattern:** Since this is a disambiguation task (not two independent selections), the dialog uses a single set of radio-buttons. The user simply selects which curve is the Rail, and the other automatically becomes the Form.

## Visual Layout

```
┌──────────────────────────────────────────────────┐
│ Select Rail Curve                                │
├──────────────────────────────────────────────────┤
│                                                  │
│ Which curve is the Rail (path to be offset)?    │
│                                                  │
│ ○ Polyline (ID: 42)                            │
│                                                  │
│ ○ Polyline (ID: 43)                            │
│                                                  │
│ The other curve will be used as Form            │
│ (profile definition).                           │
│                                                  │
│                     [OK]      [Cancel]          │
└──────────────────────────────────────────────────┘
```

## Key Features

### 1. Clear Entity Identification

Each curve is identified using the format: **`Type (ID: xxx)`**

This matches the CamBam entity tree view structure where entities are displayed by type and unique ID.

**Examples:**
- `Polyline (ID: 42)`
- `Polyline (ID: 43)`
- `Circle (ID: 15)`
- `Arc (ID: 27)`

### 2. Single Radio-Button Selection

Instead of two pairs of radio-buttons, the dialog uses a single pair:
- One radio-button per curve
- Only one can be selected at a time
- The selected curve becomes the Rail
- The unselected curve becomes the Form

**Advantages:**
- Simpler UI (less visual clutter)
- Impossible to select the same curve for both roles
- Faster decision-making for the user
- Matches standard UI patterns for disambiguation

### 3. CamBam API Best Practices

The implementation uses `PrimitiveType` property as documented in the CamBam Entity Identification Quick Reference:

```csharp
string primitiveType = curve.PrimitiveType;  // Returns "Polyline", "Circle", etc.
int id = curve.ID;                           // Unique identifier in the drawing
```

This approach is:
- **Readable:** `PrimitiveType` returns human-friendly names
- **Reliable:** `ID` is always available on every entity
- **Consistent:** Matches CamBam's own UI (entity tree view)

### 4. Contextual Help

The dialog includes a helper text: *"The other curve will be used as Form (profile definition)."*

This clarifies the relationship between the two curves and helps users understand what happens when they make their selection.

## Implementation Details

### GetCurveIdentification Method

```csharp
private string GetCurveIdentification(Polyline curve)
{
    string primitiveType = curve.PrimitiveType;  // CamBam-specific, most readable
    int id = curve.ID;                           // Every entity has this
    return $"{primitiveType} (ID: {id})";        // Format: "Polyline (ID: 42)"
}
```

This method produces the concise identification string that matches CamBam's entity tree view format.

### Role Selection Logic

```csharp
private void BtnOk_Click(object sender, EventArgs e)
{
    if (rbCurve1AsRail.Checked)
    {
        SelectedRail = _openCurves[0];
        SelectedForm = _openCurves[1];
    }
    else
    {
        SelectedRail = _openCurves[1];
        SelectedForm = _openCurves[0];
    }
}
```

The logic is straightforward: check which radio-button is selected and assign roles accordingly.

## Usage in PolylineManager

The dialog is invoked when two open curves are detected:

```csharp
else if (closedCount == 0 && openCount == 2)
{
    using (var dialog = new CurveSelectionDialog(openPolys))
    {
        if (dialog.ShowDialog() == DialogResult.OK)
        {
            manager = new PolylineManager(dialog.SelectedRail, dialog.SelectedForm, true)
            {
                CounterClosedP = closedCount,
                CounterOpenP = openCount
            };
            return true;
        }
    }
    return false;
}
```

## Testing the Dialog

### Test Case 1: Basic Display
1. Select two open polylines in CamBam
2. Invoke the MorphMuse plugin
3. Verify the dialog appears with both curves identified
4. Verify identification format matches: `Type (ID: xxx)`
5. Verify default selection (first curve as Rail)

### Test Case 2: Role Selection
1. Click the second radio-button to select the other curve as Rail
2. Verify only one radio-button is selected
3. Click OK and verify the surface is generated with the correct role assignment

### Test Case 3: Entity Type Display
1. Create curves of different types (Polyline, Arc, etc.)
2. Select two and invoke the plugin
3. Verify the correct entity type is displayed for each

### Test Case 4: ID Uniqueness
1. Create multiple curves
2. Select two and invoke the plugin
3. Verify the IDs shown in the dialog match the IDs in CamBam's entity tree view

### Test Case 5: Cancel Operation
1. Open the dialog
2. Click Cancel
3. Verify the plugin exits without generating a surface

## Advantages Over Previous Implementations

| Aspect | Original | Previous Attempt | Current |
|--------|----------|------------------|---------|
| **Interface** | Dropdowns | Two radio-button pairs | Single radio-button pair |
| **Identification** | ID + Layer only | Type + ID + Layer + Points + Status | Type + ID (matches tree view) |
| **Clarity** | Confusing | Too much information | Clear and concise |
| **User Task** | Select two roles | Select two roles | Select one role (implicit) |
| **Visual Complexity** | Medium | High | Low |
| **Matches CamBam UI** | No | No | Yes |

## Why This Design Works

1. **Matches User Mental Model:** Users already see entities in CamBam's tree view as "Type (ID: xxx)", so this format is immediately familiar

2. **Eliminates Ambiguity:** With a single selection, there's no possibility of selecting the same curve for both roles or leaving one unselected

3. **Reduces Cognitive Load:** User only needs to make one decision: "Which is the Rail?" The Form is automatically determined

4. **Minimal UI:** Clean, simple dialog that focuses on the essential task of disambiguation

5. **Accessible:** Clear labels and radio-buttons are standard UI patterns that all users understand

## Future Enhancements

Potential improvements for future versions:

1. **Visual Highlighting:** Highlight the selected curves in the CamBam drawing while the dialog is open
2. **Curve Preview:** Show a small thumbnail or wireframe of each curve
3. **Geometric Properties:** Display curve length or bounding box dimensions
4. **Auto-Detection:** Attempt to automatically detect which curve should be Rail based on geometry
5. **Keyboard Navigation:** Support arrow keys to switch between options

## Conclusion

The redesigned `CurveSelectionDialog` provides a simple, clear, and intuitive interface for disambiguating curve roles. By using a single radio-button selection and displaying entity identification in the format that matches CamBam's own UI (Type and ID), users can confidently select which curve serves as the rail and which serves as the form.
