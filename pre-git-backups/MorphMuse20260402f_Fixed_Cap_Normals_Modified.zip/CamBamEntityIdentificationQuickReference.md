# CamBam Entity Identification Quick Reference

## Question
How can we obtain programmatically the entity type and the ID identification number of an entity?

## Answer

### Getting the Entity ID

The ID is straightforward to obtain. Every entity has a readonly `ID` property:

```csharp
Entity ent = ui.ActiveView.SelectedEntities[0];
int entityID = ent.ID;
Console.WriteLine($"Entity ID: {entityID}");
```

### Getting the Entity Type

There are several options depending on your needs:

#### Option 1: Using `GetType()` (Most Common)
```csharp
Entity ent = ui.ActiveView.SelectedEntities[0];
Type entityType = ent.GetType();
string typeName = entityType.Name;

Console.WriteLine($"Entity Type: {typeName}"); // Prints "Circle", "Polyline", "Line", etc.
```

#### Option 2: Using `PrimitiveType` Property (CamBam-Specific)
Every entity has a `PrimitiveType` property that returns a human-readable string:

```csharp
Entity ent = ui.ActiveView.SelectedEntities[0];
string primitiveType = ent.PrimitiveType;

Console.WriteLine($"Primitive Type: {primitiveType}"); // Prints "Circle", "Polyline", "Line", etc.
```

#### Option 3: Using `is` or `as` for Type Checking (Safest)
If you need to perform type-specific operations, it's better to check the type before casting:

```csharp
Entity ent = ui.ActiveView.SelectedEntities[0];

if (ent is Polyline)
{
    Polyline poly = (Polyline)ent;
    Console.WriteLine($"Polyline with {poly.Points.Count} points");
}
else if (ent is Circle)
{
    Circle circle = (Circle)ent;
    Console.WriteLine($"Circle with diameter {circle.Diameter}");
}
else if (ent is Line)
{
    Line line = (Line)ent;
    Console.WriteLine($"Line entity");
}
```

## Complete Example: Iterate Over Selection and Display Information

This is a very common pattern in CamBam plugins:

```csharp
public void DisplaySelectionInfo(CamBamUI ui)
{
    if (ui.ActiveView.SelectedEntities.Length == 0)
    {
        CamBam.ThisApplication.AddLogMessage(1, "Please select some entities first.");
        return;
    }

    foreach (Entity ent in ui.ActiveView.SelectedEntities)
    {
        // Get ID and Type
        int id = ent.ID;
        string type = ent.PrimitiveType;
        
        // Log the information
        CamBam.ThisApplication.AddLogMessage(0, $"ID: {id}, Type: {type}");
        
        // Perform type-specific operations
        if (ent is Polyline)
        {
            Polyline poly = (Polyline)ent;
            CamBam.ThisApplication.AddLogMessage(0, $"  - Points: {poly.Points.Count}, Closed: {poly.Closed}");
        }
        else if (ent is Circle)
        {
            Circle circle = (Circle)ent;
            CamBam.ThisApplication.AddLogMessage(0, $"  - Diameter: {circle.Diameter}");
        }
    }
}
```

## Available Entity Types

Based on the CamBam API documentation, the main entity types are:

| Type | Description |
| :--- | :--- |
| `Polyline` | Sequence of straight lines and arcs |
| `Circle` | Perfect circle |
| `Line` | Simple straight line |
| `Arc` | Circular arc |
| `Text` / `MText` | Text |
| `Surface` | 3D mesh (triangulated) |
| `Region` | Closed region (used for boolean operations) |
| `Spline` | Smooth spline curve |

## Which Option to Use?

- **For logging/debugging**: Use `PrimitiveType` (more readable)
- **For conditional logic**: Use `is` or `as` (safer and more performant)
- **For storing type as string**: Use `GetType().Name`

## Common Use Cases

### Case 1: Filter Only Polylines from Selection
```csharp
List<Polyline> polylines = new List<Polyline>();

foreach (Entity ent in ui.ActiveView.SelectedEntities)
{
    if (ent is Polyline)
    {
        polylines.Add((Polyline)ent);
    }
}

CamBam.ThisApplication.AddLogMessage(0, $"Found {polylines.Count} polylines");
```

### Case 2: Find Entity by ID
```csharp
int targetID = 42;
Entity foundEntity = ui.ActiveView.CADFile.FindPrimitive(targetID);

if (foundEntity != null)
{
    CamBam.ThisApplication.AddLogMessage(0, $"Found entity: {foundEntity.PrimitiveType}");
}
else
{
    CamBam.ThisApplication.AddLogMessage(1, $"Entity with ID {targetID} not found");
}
```

### Case 3: Create a Dictionary of Entities by Type
```csharp
Dictionary<string, List<Entity>> entitiesByType = new Dictionary<string, List<Entity>>();

foreach (Entity ent in ui.ActiveView.CADFile.ActiveLayer.Entities)
{
    string type = ent.PrimitiveType;
    
    if (!entitiesByType.ContainsKey(type))
    {
        entitiesByType[type] = new List<Entity>();
    }
    
    entitiesByType[type].Add(ent);
}

// Now you have all entities organized by type
foreach (var kvp in entitiesByType)
{
    CamBam.ThisApplication.AddLogMessage(0, $"{kvp.Key}: {kvp.Value.Count} entities");
}
```

## References

- CamBam API Documentation - Entity: http://www.atelier-des-fougeres.fr/Cambam/Aide/API%20Doc/Cambam_cad_dll/Cambam_cad/Entity.html
- CamBam 0.9.8 API reference - Polyline: http://www.cambam.info/doc/api/Polyline.htm
- CamBam 0.9.8 API reference - Circle: http://www.cambam.info/doc/api/Circle.htm
