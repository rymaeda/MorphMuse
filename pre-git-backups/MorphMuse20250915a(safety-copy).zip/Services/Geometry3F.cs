﻿using CamBam.CAD;
using CamBam.Geom;
using System;
using System.Collections.Generic;

namespace MorphMuse.Services
{
    public static class Geometry3F
    {
        public static Vector3F FromPoints(Point3F a, Point3F b)
        {
            return new Vector3F(b.X - a.X, b.Y - a.Y, b.Z - a.Z);
        }

        public static Vector3F Subtract(Point3F a, Point3F b)
        {
            return new Vector3F(a.X - b.X, a.Y - b.Y, a.Z - b.Z);
        }

        public static Vector3F Cross(Vector3F a, Vector3F b)
        {
            return new Vector3F(
                a.Y * b.Z - a.Z * b.Y,
                a.Z * b.X - a.X * b.Z,
                a.X * b.Y - a.Y * b.X
            );
        }
        public static List<Point3F> ToPointList(PolylineItemList items)
        {
            var result = new List<Point3F>();
            foreach (PolylineItem item in items)
                result.Add(item.Point);
            return result;
        }
        public static float Dot(Vector3F a, Vector3F b)
        {
            return (float)(a.X * b.X + a.Y * b.Y + a.Z * b.Z);
        }

        public static double Length(Vector3F v)
        {
            return Math.Sqrt(v.X * v.X + v.Y * v.Y + v.Z * v.Z);
        }

        public static float Distance(Point3F a, Point3F b)
        {
            Vector3F delta = FromPoints(a, b);
            return (float)Length(delta);
        }

        public static float PerpendicularDistance(Point3F p, Point3F a, Point3F b)
        {
            Vector3F ab = FromPoints(a, b);
            Vector3F ap = FromPoints(a, p);
            Vector3F cross = Cross(ab, ap);
            float area = (float)Length(cross);
            float baseLength = (float)Length(ab);
            return baseLength == 0 ? 0 : area / baseLength;
        }

        public static Vector3F Normalize(Vector3F v)
        {
            double len = Length(v);
            return len == 0 ? new Vector3F(0, 0, 0) : new Vector3F((float)(v.X / len), (float)(v.Y / len), (float)(v.Z / len));
        }

        public static Vector3F Add(Vector3F a, Vector3F b)
        {
            return new Vector3F(a.X + b.X, a.Y + b.Y, a.Z + b.Z);
        }

        public static Vector3F Scale(Vector3F v, float factor)
        {
            return new Vector3F(v.X * factor, v.Y * factor, v.Z * factor);
        }

        public static Vector3F GetNormal(Point3F a, Point3F b, Point3F c)
        {
            Vector3F u = FromPoints(a, b);
            Vector3F v = FromPoints(a, c);
            return Normalize(Cross(u, v));
        }
    }
}