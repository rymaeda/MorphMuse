﻿using CamBam.CAD;
using CamBam.Geom;
using CamBam.UI;
using MorphMuse.Services;
using System.Collections.Generic;
using System.Drawing;

public class MorphMuseController
{
    private readonly CamBamUI _ui;

    public MorphMuseController(CamBamUI ui)
    {
        _ui = ui;
    }

    public void Execute()
    {
        if (!PolylineManager.TryCreateFromSelection(out PolylineManager manager))
            return;

        var processor = new OpenPolylineProcessor(manager.OpenPoly, 0.1, 0.3);
        var orderedContours = LayerGenerator.GenerateContoursByGeratrizOrder(manager.ClosedPoly, processor.SimplifiedPoints);

        var sampledCurves = CurveSampler.GenerateSampledPointsFromContours(orderedContours, processor.SimplifiedPoints, 0.5, 1);
        var simplifiedCurves = SimplifyAll(sampledCurves);

        for (int i = 0; i < simplifiedCurves.Count - 1; i++)
        {
            var lower = simplifiedCurves[i];
            var upper = simplifiedCurves[i + 1];

            Surface malha = SurfaceBuilderCopilot.BuildSurfaceBetweenCurves(lower, upper);
            _ui.ActiveView.CADFile.Add(malha);

            var faixa = SurfaceBuilder.TriangulateBetweenCurvesAdaptive(lower, upper);
            string layerName = CreateUniqueLayer("Faixa_");
            TriangleVisualizer.VisualizeTrianglesX(faixa, layerName);
        }

        _ui.ActiveView.ZoomToFit();
        _ui.ActiveView.RefreshView();
    }

    private List<List<Point3F>> SimplifyAll(List<List<Point3F>> curves)
    {
        var result = new List<List<Point3F>>();
        foreach (var curve in curves)
            result.Add(PolylineSimplifier.SimplifyDouglasPeucker(curve, 0.1));
        return result;
    }

    private string CreateUniqueLayer(string baseName)
    {
        int index = 1;
        string layerName;
        var cadFile = _ui.ActiveView.CADFile;

        do
        {
            layerName = $"{baseName}{index:D4}";
            index++;
        }
        while (cadFile.HasLayer(layerName));

        cadFile.CreateLayer(layerName);
        cadFile.SetActiveLayer(layerName);
        return layerName;
    }
}