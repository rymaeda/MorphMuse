﻿using CamBam.CAD;
using CamBam.Geom;
using CamBam.UI;
using MorphMuse.Services;
using System.Collections.Generic;

public class MorphMuseController
{
    private readonly CamBamUI _ui;

    public MorphMuseController(CamBamUI ui)
    {
        _ui = ui;
    }

    public void Execute()
    {
        if (!PolylineManager.TryCreateFromSelection(out PolylineManager manager))
            return;

        var processor = new OpenPolylineProcessor(manager.OpenPoly, 0.1, 0.3);
        var orderedContours = LayerGenerator.GenerateContoursByGeratrizOrder(manager.ClosedPoly, processor.SimplifiedPoints);

        var sampledCurves = CurveSampler.GenerateSampledPointsFromContours(orderedContours, processor.SimplifiedPoints, 0.5, 1);
        var simplifiedCurves = SimplifyAll(sampledCurves);

        if (simplifiedCurves.Count < 2)
            return;

        string layerName = CreateUniqueLayer("MalhaFinal");
        Layer layer = _ui.ActiveView.CADFile.Layers[layerName];
        layer.Color = System.Drawing.Color.DarkGoldenrod;

        Point3FArray allPoints = new Point3FArray();
        Dictionary<Point3F, int> pointIndex = new Dictionary<Point3F, int>();
        List<TriangleFace> allFaces = new List<TriangleFace>();

        for (int i = 0; i < simplifiedCurves.Count - 1; i++)
        {
            List<Point3F> lower = simplifiedCurves[i];
            List<Point3F> upper = simplifiedCurves[i + 1];

            List<Triangle> triangles = SurfaceBuilder.TriangulateBetweenCurvesDirect(lower, upper);

            for (int t = 0; t < triangles.Count; t++)
            {
                Triangle tri = triangles[t];
                int ia = AddPoint(tri.A, allPoints, pointIndex);
                int ib = AddPoint(tri.B, allPoints, pointIndex);
                int ic = AddPoint(tri.C, allPoints, pointIndex);
                allFaces.Add(new TriangleFace(ia, ib, ic));
            }
        }

        Surface finalSurface = new Surface();
        finalSurface.Points = allPoints;
        finalSurface.Faces = allFaces.ToArray();

        _ui.ActiveView.CADFile.Add(finalSurface);
        _ui.ActiveView.ZoomToFit();
        _ui.ActiveView.RefreshView();
    }

    private List<List<Point3F>> SimplifyAll(List<List<Point3F>> curves)
    {
        List<List<Point3F>> result = new List<List<Point3F>>();
        for (int i = 0; i < curves.Count; i++)
            result.Add(PolylineSimplifier.SimplifyDouglasPeucker(curves[i], 0.1));
        return result;
    }

    private int AddPoint(Point3F p, Point3FArray points, Dictionary<Point3F, int> indexMap)
    {
        int index;
        if (!indexMap.TryGetValue(p, out index))
        {
            index = points.Count;
            points.Add(p);
            indexMap[p] = index;
        }
        return index;
    }

    private string CreateUniqueLayer(string baseName)
    {
        int index = 1;
        string layerName;
        CADFile cadFile = _ui.ActiveView.CADFile;

        do
        {
            layerName = baseName + index.ToString("D4");
            index++;
        }
        while (cadFile.HasLayer(layerName));

        cadFile.CreateLayer(layerName);
        cadFile.SetActiveLayer(layerName);
        return layerName;
    }
}