﻿using CamBam.Geom;
using CamBam.CAD;
using System.Collections.Generic;

namespace MorphMuse.Services
{
    public static class SurfaceBuilderCopilot
    {
        /// <summary>
        /// Gera uma malha sólida entre duas curvas de nível, com orientação global e sem triângulos degenerados.
        /// </summary>
        public static Surface BuildSurfaceBetweenCurves(List<Point3F> lower, List<Point3F> upper,
                                                        ref bool hasReference, ref Vector3F referenceNormal)
        {
            var points = new Point3FArray();
            var pointIndex = new Dictionary<Point3F, int>();
            var faces = new List<TriangleFace>();

            int i = 0, j = 0;

            // Garante que as curvas estejam alinhadas no mesmo sentido
            if (!AreCurvesAligned(lower, upper))
                upper.Reverse();

            while (i < lower.Count - 1 || j < upper.Count - 1)
            {
                Point3F a = lower[i];
                Point3F b = upper[j];

                bool canAdvanceLower = i < lower.Count - 1;
                bool canAdvanceUpper = j < upper.Count - 1;

                if (canAdvanceLower && (!canAdvanceUpper || Geometry3F.Distance(lower[i + 1], b) < Geometry3F.Distance(a, upper[j + 1])))
                {
                    Point3F aNext = lower[i + 1];
                    AddTriangle(a, aNext, b, ref hasReference, ref referenceNormal, points, pointIndex, faces);
                    i++;
                }
                else if (canAdvanceUpper)
                {
                    Point3F bNext = upper[j + 1];
                    AddTriangle(a, bNext, b, ref hasReference, ref referenceNormal, points, pointIndex, faces);
                    j++;
                }
                else
                {
                    break;
                }
            }

            return new Surface
            {
                Points = points,
                Faces = faces.ToArray()
            };
        }

        private static void AddTriangle(Point3F a, Point3F b, Point3F c,
                                        ref bool hasReference, ref Vector3F referenceNormal,
                                        Point3FArray points,
                                        Dictionary<Point3F, int> pointIndex,
                                        List<TriangleFace> faces)
        {
            if (IsDegenerate(a, b, c)) return;

            int ia = AddPoint(a, points, pointIndex);
            int ib = AddPoint(b, points, pointIndex);
            int ic = AddPoint(c, points, pointIndex);

            Vector3F normal = Geometry3F.GetNormal(a, b, c);
            double length = Geometry3F.Length(normal);
            if (length < 1e-6) return;

            Vector3F unitNormal = Geometry3F.Scale(normal, (float)(1.0 / length));

            if (!hasReference)
            {
                referenceNormal = unitNormal;
                hasReference = true;
                faces.Add(new TriangleFace(ia, ib, ic));
                return;
            }

            double dot = Vector3F.DotProduct(unitNormal, referenceNormal);
            faces.Add(dot < 0 ? new TriangleFace(ia, ic, ib) : new TriangleFace(ia, ib, ic));
        }

        private static int AddPoint(Point3F p, Point3FArray points, Dictionary<Point3F, int> indexMap)
        {
            if (!indexMap.TryGetValue(p, out int index))
            {
                index = points.Count;
                points.Add(p);
                indexMap[p] = index;
            }
            return index;
        }

        private static bool IsDegenerate(Point3F a, Point3F b, Point3F c)
        {
            Vector3F ab = Geometry3F.FromPoints(a, b);
            Vector3F ac = Geometry3F.FromPoints(a, c);
            Vector3F cross = Geometry3F.Cross(ab, ac);
            double area = Geometry3F.Length(cross) * 0.5;
            return area < 1e-6;
        }

        private static bool AreCurvesAligned(List<Point3F> a, List<Point3F> b)
        {
            return Geometry3F.Distance(a[0], b[0]) < Geometry3F.Distance(a[0], b[b.Count - 1]);
        }
    }
}