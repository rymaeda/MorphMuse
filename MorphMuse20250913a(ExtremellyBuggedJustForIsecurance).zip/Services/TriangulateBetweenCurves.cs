﻿using CamBam.Geom;
using System;
using System.Collections.Generic;

namespace MorphMuse.Services
{
    public static class SurfaceBuilder
    {
        public static List<Triangle> TriangulateBetweenCurvesDirect(List<Point3F> lower, List<Point3F> upper)
        {
            var triangles = new List<Triangle>();

            int count = Math.Min(lower.Count, upper.Count) - 1;

            for (int k = 0; k < count; k++)
            {
                Point3F a = lower[k];
                Point3F b = upper[k];
                Point3F aNext = lower[k + 1];
                Point3F bNext = upper[k + 1];

                if (!IsDegenerate(a, b, aNext))
                    triangles.Add(FixOrientation(new Triangle(a, b, aNext)));

                if (!IsDegenerate(aNext, b, bNext))
                    triangles.Add(FixOrientation(new Triangle(aNext, b, bNext)));
            }

            return triangles;
        }

        //private static Triangle FixOrientation(Triangle t)
        //{
        //    Vector3F normal = Geometry3F.GetNormal(t.A, t.B, t.C);
        //    return normal.Z < 0 ? new Triangle(t.A, t.C, t.B) : t;
        //}
        private static Triangle FixOrientation(Triangle t)
        {
            Vector3F normal = Geometry3F.GetNormal(t.A, t.B, t.C);
            if (normal.Z < 0)
                return new Triangle(t.A, t.C, t.B);
            return t;
        }

        private static bool AreCurvesAligned(List<Point3F> a, List<Point3F> b)
        {
            return Geometry3F.Distance(a[0], b[0]) < Geometry3F.Distance(a[0], b[b.Count - 1]);
        }







        private static bool IsDegenerate(Point3F a, Point3F b, Point3F c)
        {
            Vector3F ab = Geometry3F.FromPoints(a, b);
            Vector3F ac = Geometry3F.FromPoints(a, c);
            Vector3F cross = Geometry3F.Cross(ab, ac);
            double area = Geometry3F.Length(cross) * 0.5;
            return area < 1e-6;
        }
    }
}