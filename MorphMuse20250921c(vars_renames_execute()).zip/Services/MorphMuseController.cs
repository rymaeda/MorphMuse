﻿using CamBam.CAD;
using CamBam.Geom;
using CamBam.UI;
using MorphMuse;
using MorphMuse.Services;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
public class MorphMuseController
{
    private readonly CamBamUI _ui;
    private Form1 _formInstance;

    public MorphMuseController(CamBamUI ui)
    {
        _ui = ui;
    }

    public void Execute()
    {
        if (!PolylineManager.TryCreateFromSelection(out PolylineManager selectionManager))
        {
            MessageBox.Show("Select at least one open polyline and one closed polyline.");

            if (_formInstance == null || _formInstance.IsDisposed)
            {
                _formInstance = new Form1();
                _formInstance.StartPosition = FormStartPosition.CenterParent;
                _formInstance.Show(Form.ActiveForm);
            }
            else
            {
                _formInstance.BringToFront();
            }

            return;
        }

        var openCurveProcessor = new OpenPolylineProcessor(selectionManager.OpenPoly, 0.01, 0.01);

        var orderedClosedCurves = LayerGenerator.GenerateContoursByGeratrizOrder(
            selectionManager.ClosedPoly,
            openCurveProcessor.SimplifiedPoints
        );

        var sampledClosedCurves = CurveSampler.GenerateSampledPointsFromContours(
            orderedClosedCurves,
            openCurveProcessor.SimplifiedPoints,
            0.05,
            0.05
        );

        var simplifiedClosedCurves = SimplifyAll(sampledClosedCurves);
        if (simplifiedClosedCurves.Count < 2)
            return;

        string originalLayerName = _ui.ActiveView.CADFile.ActiveLayerName;
        string surfaceLayerName = CreateUniqueLayer("MorphSurface");
        Layer layer = _ui.ActiveView.CADFile.Layers[surfaceLayerName];
        layer.Color = Color.DeepSkyBlue;

        Point3FArray finalSurfacePoints = new Point3FArray();
        Dictionary<Point3F, int> finalPointIndex = new Dictionary<Point3F, int>();
        List<TriangleFace> finalSurfaceFaces = new List<TriangleFace>();

        for (int i = 0; i < simplifiedClosedCurves.Count - 1; i++)
        {
            var lower = simplifiedClosedCurves[i];
            var upper = simplifiedClosedCurves[i + 1];

            Surface partialSurface = SurfaceBuilderCopilot.BuildSurfaceBetweenCurves(lower, upper);

            for (int f = 0; f < partialSurface.Faces.Length; f++)
            {
                TriangleFace face = partialSurface.Faces[f];

                Point3F pa = partialSurface.Points[face.A];
                Point3F pb = partialSurface.Points[face.B];
                Point3F pc = partialSurface.Points[face.C];

                int ia = AddPoint(pa, finalSurfacePoints, finalPointIndex);
                int ib = AddPoint(pb, finalSurfacePoints, finalPointIndex);
                int ic = AddPoint(pc, finalSurfacePoints, finalPointIndex);

                finalSurfaceFaces.Add(new TriangleFace(ia, ib, ic));
            }
        }

        if (selectionManager.ClosedPoly == null || selectionManager.ClosedPoly.Points.Count < 3)
            return;

        if (orderedClosedCurves == null || orderedClosedCurves.Count == 0)
            return;

        List<Polyline> lastClosedGroup = orderedClosedCurves[orderedClosedCurves.Count - 1];
        Polyline lastClosedPolyline = lastClosedGroup[lastClosedGroup.Count - 1];

        FanCapGenerator.FindConvergenceCentersAndCurves(
            lastClosedPolyline,
            0.1,
            10.0,
            0.01f,
            out List<Point3F> topCapCenters,
            out List<Polyline> curvesToClose
        );

        float zTop = (float)simplifiedClosedCurves[simplifiedClosedCurves.Count - 1][0].Z;

        for (int i = 0; i < curvesToClose.Count; i++)
        {
            Polyline poly = curvesToClose[i];
            for (int k = 0; k < lastClosedPolyline.Points.Count; k++)
            {
                PolylineItem item = lastClosedPolyline.Points[k];
                Point3F pt = item.Point;
                item.Point = new Point3F(pt.X, pt.Y, zTop);
                lastClosedPolyline.Points[k] = item;
            }
        }

        for (int i = 0; i < topCapCenters.Count; i++)
        {
            Point3F pt = topCapCenters[i];
            topCapCenters[i] = new Point3F(pt.X, pt.Y, zTop);
        }

        List<Point3F> topmostSimplifiedCurve = simplifiedClosedCurves[simplifiedClosedCurves.Count - 1];
        Point3F topCapCenter = GetCentroid(topmostSimplifiedCurve);

        Point3FArray capSurfacePoints = new Point3FArray();
        Dictionary<Point3F, int> capPointIndex = new Dictionary<Point3F, int>();
        List<TriangleFace> capSurfaceFaces = new List<TriangleFace>();

        int centerIndex = AddPoint(topCapCenter, capSurfacePoints, capPointIndex);

        for (int i = 0; i < topmostSimplifiedCurve.Count - 1; i++)
        {
            Point3F pa = topmostSimplifiedCurve[i];
            Point3F pb = topmostSimplifiedCurve[i + 1];

            int ia = AddPoint(pa, capSurfacePoints, capPointIndex);
            int ib = AddPoint(pb, capSurfacePoints, capPointIndex);

            capSurfaceFaces.Add(new TriangleFace(centerIndex, ia, ib));
        }

        int iaLast = AddPoint(topmostSimplifiedCurve[topmostSimplifiedCurve.Count - 1], capSurfacePoints, capPointIndex);
        int ibFirst = AddPoint(topmostSimplifiedCurve[0], capSurfacePoints, capPointIndex);
        capSurfaceFaces.Add(new TriangleFace(centerIndex, iaLast, ibFirst));

        for (int f = 0; f < capSurfaceFaces.Count; f++)
        {
            TriangleFace face = capSurfaceFaces[f];

            Point3F pa = capSurfacePoints[face.A];
            Point3F pb = capSurfacePoints[face.B];
            Point3F pc = capSurfacePoints[face.C];

            int ia = AddPoint(pa, finalSurfacePoints, finalPointIndex);
            int ib = AddPoint(pb, finalSurfacePoints, finalPointIndex);
            int ic = AddPoint(pc, finalSurfacePoints, finalPointIndex);

            finalSurfaceFaces.Add(new TriangleFace(ia, ib, ic));
        }

        Surface surfaceEntity = new Surface
        {
            Points = finalSurfacePoints,
            Faces = finalSurfaceFaces.ToArray()
        };

        _ui.ActiveView.CADFile.Add(surfaceEntity);
        _ui.ActiveView.CADFile.SetActiveLayer(originalLayerName);
        _ui.ActiveView.ZoomToFit();
        _ui.ActiveView.RefreshView();
    }

    private int AddPoint(Point3F p, Point3FArray points, Dictionary<Point3F, int> indexMap)
    {
        if (!indexMap.TryGetValue(p, out int index))
        {
            index = points.Count;
            points.Add(p);
            indexMap[p] = index;
        }
        return index;
    }

    private List<List<Point3F>> SimplifyAll(List<List<Point3F>> curves)
    {
        var result = new List<List<Point3F>>();
        foreach (var curve in curves)
            result.Add(PolylineSimplifier.SimplifyDouglasPeucker(curve, 0.001));
        return result;
    }

    private Point3F GetCentroid(List<Point3F> points)
    {
        if (points == null || points.Count == 0)
            return new Point3F(0, 0, 0);

        float sumX = 0, sumY = 0, sumZ = 0;
        foreach (Point3F pt in points)
        {
            sumX += (float)pt.X;
            sumY += (float)pt.Y;
            sumZ += (float)pt.Z;
        }

        int count = points.Count;
        return new Point3F(sumX / count, sumY / count, sumZ / count);
    }

    private string CreateUniqueLayer(string baseName)
    {
        int index = 1;
        string layerName;
        var cadFile = _ui.ActiveView.CADFile;

        do
        {
            layerName = $"{baseName}{index:D4}";
            index++;
        }
        while (cadFile.HasLayer(layerName));

        cadFile.CreateLayer(layerName);
        cadFile.SetActiveLayer(layerName);
        return layerName;
    }
}