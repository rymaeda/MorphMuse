﻿using CamBam.Geom;
using System.Collections.Generic;
using MorphMuse.Services;

public static class SurfaceBuilder
{
    public static List<Triangle> TriangulateBetweenCurves(List<Point3F> lower, List<Point3F> upper)
    {
        List<Triangle> triangles = new List<Triangle>();

        int i = 0; // índice da curva inferior
        int j = 0; // índice da curva superior

        while (i < lower.Count - 1 && j < upper.Count - 1)
        {
            Point3F a = lower[i];
            Point3F b = upper[j];
            Point3F aNext = lower[i + 1];
            Point3F bNext = upper[j + 1];

            double da = Geometry3F.Distance(a, aNext);
            double db = Geometry3F.Distance(b, bNext);

            if (da < db)
            {
                // Triângulo: a, b, aNext
                triangles.Add(new Triangle(a, b, aNext));
                i++;
            }
            else
            {
                // Triângulo: a, b, bNext
                triangles.Add(new Triangle(a, b, bNext));
                j++;
            }
        }

        // Finaliza os últimos segmentos
        while (i < lower.Count - 1)
        {
            triangles.Add(new Triangle(lower[i], upper[j], lower[i + 1]));
            i++;
        }

        while (j < upper.Count - 1)
        {
            triangles.Add(new Triangle(lower[i], upper[j], upper[j + 1]));
            j++;
        }

        return triangles;
    }
}