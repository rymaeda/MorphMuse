﻿using CamBam.CAD;
using CamBam.Geom;
using CamBam.UI;
using MorphMuse.Services;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace CambamPlugin
{
    public class Program
    {
        public static CamBamUI _ui;
        // This is the main entry point into the plugin.
        public static void InitPlugin(CamBamUI ui)
        {
            // Store a reference to the CamBamUI object passed to InitPlugin
            _ui = ui;

            // Create a new menu item in the top Plugins menu
            ToolStripMenuItem mi = new ToolStripMenuItem();
            mi.Text = "MorphMuse";
            mi.Click += new EventHandler(MorphMuse_Click);
            ui.Menus.mnuPlugins.DropDownItems.Add(mi);
        }

        static void MorphMuse_Click(object sender, EventArgs e)
        {
            if (!PolylineManager.TryCreateFromSelection(out PolylineManager manager))
                return;

            string layerName = CreateUniqueLayer("ParallelCurves");
            Layer layer = _ui.ActiveView.CADFile.Layers[layerName];
            layer.Color = Color.DodgerBlue;

            // Process Open Polyline: remove arcs and simplify
            OpenPolylineProcessor processor = new OpenPolylineProcessor(manager.OpenPoly, 0.1, 0.3);

            // Generate parallel curves ordered by geratriz position
            var orderedContours = LayerGenerator.GenerateContoursByGeratrizOrder(
                manager.ClosedPoly,
                processor.SimplifiedPoints
            );

            //for (int i = 0; i < orderedContours.Count; i++)
            //{
            //    var curves = orderedContours[i];
            //    foreach (var curve in curves)
            //    {
            //        CamBamUI.MainUI.ActiveView.CADFile.Add(curve);
            //    }
            //}
            var sampledCurves = CurveSampler.GenerateSampledPointsFromContours(
                orderedContours,
                processor.SimplifiedPoints,
                baseDensity: 0.5,
                minStep: 1
            );

            var simplifiedCurves = new List<List<Point3F>>();

            for (int i = 0; i < sampledCurves.Count; i++)
            {
                var simplificada = PolylineSimplifier.SimplifyDouglasPeucker(sampledCurves[i], 0.1);
                simplifiedCurves.Add(simplificada);
            }

            for (int k = 0; k < simplifiedCurves.Count - 1; k++)
            {
                var lower = simplifiedCurves[k];
                var upper = simplifiedCurves[k + 1];

                List<Triangle> malha = SurfaceBuilder.TriangulateBetweenCurves(lower, upper);

                // Aqui você pode visualizar ou exportar os triângulos
            }
            //CurveVisualizer.VisualizeSampledCurves(sampledCurves);
            //PointVisualizer.VisualizePointsOnly(sampledCurves, "Pontos", 0.2, 3000);
            //PointVisualizer.VisualizePointsOnly(simplifiedCurves, "Pontos", 0.2, 3000);


            //for (int i = 0; i < sampledCurves.Count; i++)
            //{
            //    List<Point3F> curvePoints = sampledCurves[i];

            //    Polyline preview = new Polyline();
            //    for (int j = 0; j < curvePoints.Count; j++)
            //    {
            //        preview.Add(curvePoints[j]);
            //    }

            //    preview.Closed = false;
            //    CamBamUI.MainUI.ActiveView.CADFile.Layers[0].Add(preview);
            //}

            List<Triangle> malhaCompleta = new List<Triangle>();


            for (int i = 0; i < sampledCurves.Count - 1; i++)
            {
                var lower = simplifiedCurves[i];
                var upper = simplifiedCurves[i + 1];
                var faixa = SurfaceBuilder.TriangulateBetweenCurves(lower, upper);

                string layerName2 = CreateUniqueLayer("Faixa_");
                TriangleVisualizer.VisualizeTrianglesX(faixa, layerName2);
            }
            _ui.ActiveView.ZoomToFit();
            _ui.ActiveView.RefreshView();
        }


        private static string CreateUniqueLayer(string baseName)
        {
            int index = 1;
            string layerName;

            do
            {
                layerName = $"{baseName}{index:D4}";
                index++;
            }
            while (_ui.ActiveView.CADFile.HasLayer(layerName));

            _ui.ActiveView.CADFile.CreateLayer(layerName);
            _ui.ActiveView.CADFile.SetActiveLayer(layerName);

            return layerName;
        }
    }// class
}