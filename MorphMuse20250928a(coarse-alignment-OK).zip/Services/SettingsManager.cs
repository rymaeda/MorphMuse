﻿using CamBam.CAD;
using CamBam.Geom;
using CamBam.UI;
using MorphMuse.Properties;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PluginSettings

{
    public class SettingsManager
    {
        public enum Units
        {
            Millimeters = 0,
            Inches = 1,
            Centimeters = 2,
            Meters = 3,
            Thousandths = 4,
            Unknown = -1
        }

        public static Units GetUnits()
        {
            try
            {
                return (Units)CamBamUI.MainUI.ActiveView.CADFile.DrawingUnits;
            }
            catch
            {
                return Units.Unknown;
            }
        }

        public Units CurrentUnits { get; private set; } = Units.Millimeters;
        // Parâmetros configuráveis
        public float DefaultTolerance { get; set; } = 0.01f;
        public float DefaultOffsetStep { get; set; } = 0.5f;
        public bool UseAdvancedMode { get; set; } = false;

        public void LoadFromDocument(CADFile doc)
        {
            CurrentUnits = GetUnits();
            CamBam.ThisApplication.AddLogMessage($"[Settings] Units loaded: {CurrentUnits}");
        }

        public float ConvertToMillimeters(float value)
        {
            switch (CurrentUnits)
            {
                case Units.Inches: return value * 25.4f;
                case Units.Centimeters: return value * 10f;
                case Units.Meters: return value * 1000f;
                case Units.Thousandths: return value * 0.0254f;
                case Units.Millimeters: return value;
                default: return value;
            }
        }

        public float ConvertFromMillimeters(float valueInMm)
        {
            switch (CurrentUnits)
            {
                case Units.Inches: return valueInMm / 25.4f;
                case Units.Centimeters: return valueInMm / 10f;
                case Units.Meters: return valueInMm / 1000f;
                case Units.Thousandths: return valueInMm / 0.0254f;
                case Units.Millimeters: return valueInMm;
                default: return valueInMm;
            }
        }
    }
}
