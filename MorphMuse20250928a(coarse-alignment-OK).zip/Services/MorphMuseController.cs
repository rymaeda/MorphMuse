﻿using CamBam.CAD;
using CamBam.Geom;
using CamBam.UI;
using MorphMuse;
using MorphMuse.Services;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
public class MorphMuseController
{
    private readonly CamBamUI _ui;
    private Form1 _formInstance;

    public MorphMuseController(CamBamUI ui)
    {
        _ui = ui;
    }

    public void Execute()
    {
        if (!PolylineManager.ValidateSelection(out PolylineManager selectionManager))
        {
            ShowFallbackForm();
            return;
        }

        var simplifiedClosedCurves = PrepareClosedCurves(selectionManager);
        if (simplifiedClosedCurves.Count < 2)
            return;
        string originalLayerName = _ui.ActiveView.CADFile.ActiveLayerName;
        string surfaceLayerName = CreateUniqueLayer("MorphSurface");
        Layer layer = _ui.ActiveView.CADFile.Layers[surfaceLayerName];
        layer.Color = Color.DeepSkyBlue;

        Point3FArray finalSurfacePoints = new Point3FArray();
        Dictionary<Point3F, int> finalPointIndex = new Dictionary<Point3F, int>();
        List<TriangleFace> finalSurfaceFaces = new List<TriangleFace>();

        SurfaceBuilderCopilot.GenerateLateralSurface(simplifiedClosedCurves, finalSurfacePoints, finalPointIndex, finalSurfaceFaces);

        List<Point3F> topmostSimplifiedCurve = simplifiedClosedCurves[simplifiedClosedCurves.Count - 1];
        Point3F topCapCenter = GetCentroid(topmostSimplifiedCurve);
        SurfaceBuilderCopilot.GenerateCapSurface(topmostSimplifiedCurve, topCapCenter, finalSurfacePoints, finalPointIndex, finalSurfaceFaces);

        Surface surfaceEntity = new Surface
        {
            Points = finalSurfacePoints,
            Faces = finalSurfaceFaces.ToArray()
        };

        _ui.ActiveView.CADFile.Add(surfaceEntity);
        _ui.ActiveView.CADFile.SetActiveLayer(originalLayerName);
        _ui.ActiveView.ZoomToFit();
        _ui.ActiveView.RefreshView();
    }



    private List<List<Point3F>> PrepareClosedCurves(PolylineManager selectionManager)
    {
        var openCurveProcessor = new OpenPolylineProcessor(selectionManager.OpenPoly, 0.01, 0.01);

        var orderedClosedCurves = LayerGenerator.GenerateContoursByGeratrizOrder(
            selectionManager.ClosedPoly,
            openCurveProcessor.SimplifiedPoints
        );

        var sampledClosedCurves = CurveSampler.GenerateSampledPointsFromContours(
            orderedClosedCurves,
            openCurveProcessor.SimplifiedPoints,
            0.05,
            0.05
        );

        return SimplifyAll(sampledClosedCurves);
    }

    private List<List<Point3F>> SimplifyAll(List<List<Point3F>> curves)
    {
        var result = new List<List<Point3F>>();
        foreach (var curve in curves)
            result.Add(PolylineSimplifier.SimplifyDouglasPeucker(curve, 0.001));
        return result;
    }

    private Point3F GetCentroid(List<Point3F> points)
    {
        if (points == null || points.Count == 0)
            return new Point3F(0, 0, 0);

        float sumX = 0, sumY = 0, sumZ = 0;
        foreach (Point3F pt in points)
        {
            sumX += (float)pt.X;
            sumY += (float)pt.Y;
            sumZ += (float)pt.Z;
        }

        int count = points.Count;
        return new Point3F(sumX / count, sumY / count, sumZ / count);
    }

    private string CreateUniqueLayer(string baseName)
    {
        int index = 1;
        string layerName;
        var cadFile = _ui.ActiveView.CADFile;

        do
        {
            layerName = $"{baseName}{index:D4}";
            index++;
        }
        while (cadFile.HasLayer(layerName));

        cadFile.CreateLayer(layerName);
        cadFile.SetActiveLayer(layerName);
        return layerName;
    }
    private void ShowFallbackForm()
    {
        if (_formInstance == null || _formInstance.IsDisposed)
        {
            _formInstance = new Form1();
            _formInstance.StartPosition = FormStartPosition.CenterParent;
            _formInstance.Show(Form.ActiveForm);
        }
        else
        {
            _formInstance.BringToFront();
        }
    }
}