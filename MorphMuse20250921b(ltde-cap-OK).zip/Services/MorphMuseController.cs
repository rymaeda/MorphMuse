﻿using CamBam.CAD;
using CamBam.Geom;
using CamBam.UI;
using MorphMuse.Services;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

public class MorphMuseController
{
    private readonly CamBamUI _ui;

    public MorphMuseController(CamBamUI ui)
    {
        _ui = ui;
    }

    public void Execute()
    {
        // Attempt to retrieve selected polylines from the current CAD view
        if (!PolylineManager.TryCreateFromSelection(out PolylineManager manager))
        {
            MessageBox.Show("Select at least one open polyline and one closed polyline.");
            return;
        }
        // Process the open polyline (generatrix) with smoothing parameters
        var processor = new OpenPolylineProcessor(manager.OpenPoly, 0.01, 0.01);

        // Order closed polylines (contours) based on their relation to the generatrix
        var orderedContours = LayerGenerator.GenerateContoursByGeratrizOrder(
            manager.ClosedPoly,
            processor.SimplifiedPoints
        );

        // Sample points along the contours with controlled density
        var sampledCurves = CurveSampler.GenerateSampledPointsFromContours(
            orderedContours,
            processor.SimplifiedPoints,
            0.05,
            0.05
        );

        // Simplify each sampled curve to reduce geometric complexity
        var simplifiedCurves = SimplifyAll(sampledCurves);

        // Abort if there are not enough curves to build a surface
        if (simplifiedCurves.Count < 2)
            return;

        // Save the currently active layer to restore it later
        string originalLayerName = _ui.ActiveView.CADFile.ActiveLayerName;

        // Create a new layer to store the final mesh
        string layerName = CreateUniqueLayer("Mesh");
        Layer layer = _ui.ActiveView.CADFile.Layers[layerName];
        layer.Color = Color.DeepSkyBlue;

        // Structures to accumulate all vertices and faces of the final surface
        Point3FArray allPoints = new Point3FArray();
        Dictionary<Point3F, int> pointIndex = new Dictionary<Point3F, int>();
        List<TriangleFace> allFaces = new List<TriangleFace>();

        // Generate surfaces between each pair of consecutive curves
        for (int i = 0; i < simplifiedCurves.Count - 1; i++)
        {
            var lower = simplifiedCurves[i];
            var upper = simplifiedCurves[i + 1];

            Surface partialSurface = SurfaceBuilderCopilot.BuildSurfaceBetweenCurves(lower, upper);

            // Reindex the vertices of the partial surface into the final mesh
            for (int f = 0; f < partialSurface.Faces.Length; f++)
            {
                TriangleFace face = partialSurface.Faces[f];

                Point3F pa = partialSurface.Points[face.A];
                Point3F pb = partialSurface.Points[face.B];
                Point3F pc = partialSurface.Points[face.C];

                int ia = AddPoint(pa, allPoints, pointIndex);
                int ib = AddPoint(pb, allPoints, pointIndex);
                int ic = AddPoint(pc, allPoints, pointIndex);

                allFaces.Add(new TriangleFace(ia, ib, ic));
            }
        }
        if (manager.ClosedPoly == null || manager.ClosedPoly.Points.Count < 3)
            return;

        List<Point3F> centers;
        List<Polyline> curvesToClose;
        if (orderedContours == null || orderedContours.Count == 0)
            return;
        List<Polyline> lastGroup = orderedContours[orderedContours.Count - 1];
        Polyline closedBaseLast = lastGroup[lastGroup.Count - 1];

        FanCapGenerator.FindConvergenceCentersAndCurves(
            closedBaseLast,
            0.1,
            10.0,
            0.01f,
            out centers,
            out curvesToClose
        );
      
        // Create the final consolidated surface
        float zTop = (float)simplifiedCurves[simplifiedCurves.Count - 1][0].Z;
        for (int i = 0; i < curvesToClose.Count; i++)
        {
            Polyline poly = curvesToClose[i];
            for (int k = 0; k < closedBaseLast.Points.Count; k++)
            {
                PolylineItem item = closedBaseLast.Points[k]; // item copy
                Point3F pt = item.Point;
                item.Point = new Point3F(pt.X, pt.Y, zTop);   // modify the copy
                closedBaseLast.Points[k] = item;              // reassign list
            }
        }
        // Adjust centers to the top Z level
        for (int i = 0; i < centers.Count; i++)
        {
            Point3F pt = centers[i];
            centers[i] = new Point3F(pt.X, pt.Y, zTop);
        }
        // Build the cap using the topmost simplified curve and its center
        //Polyline curve = closedBaseLast;
        List<Point3F> topCurve = simplifiedCurves[simplifiedCurves.Count - 1];
        //Point3F center = centers[0];
        Point3F center = Geometry3F.GetCentroid(topCurve);
        Point3FArray capPoints = new Point3FArray();
        Dictionary<Point3F, int> capIndex = new Dictionary<Point3F, int>();
        List<TriangleFace> capFaces = new List<TriangleFace>();

        int ic2 = AddPoint(center, capPoints, capIndex);

        for (int i = 0; i < topCurve.Count - 1; i++)
        {
            Point3F pa = topCurve[i];
            Point3F pb = topCurve[i + 1];

            int ia = AddPoint(pa, capPoints, capIndex);
            int ib = AddPoint(pb, capPoints, capIndex);

            TriangleFace tri = new TriangleFace(ic2, ia, ib);
            capFaces.Add(tri);
        }

        int iaLast = AddPoint(topCurve[topCurve.Count - 1], capPoints, capIndex);
        int ibFirst = AddPoint(topCurve[0], capPoints, capIndex);
        capFaces.Add(new TriangleFace(ic2, iaLast, ibFirst));
        // Final mesh reindexing
        for (int f = 0; f < capFaces.Count; f++)
        {
            TriangleFace face = capFaces[f];

            Point3F pa = capPoints[face.A];
            Point3F pb = capPoints[face.B];
            Point3F pc = capPoints[face.C];

            int ia = AddPoint(pa, allPoints, pointIndex);
            int ib = AddPoint(pb, allPoints, pointIndex);
            int icFinal = AddPoint(pc, allPoints, pointIndex);

            allFaces.Add(new TriangleFace(ia, ib, icFinal));
        }
        Surface finalSurface = new Surface
        {
            Points = allPoints,
            Faces = allFaces.ToArray()
        };

        // Add the surface to the newly created layer
        _ui.ActiveView.CADFile.Add(finalSurface);

        // Restore the previously active layer
        _ui.ActiveView.CADFile.SetActiveLayer(originalLayerName);

        // Adjust the view to fit the new geometry and refresh the display
        _ui.ActiveView.ZoomToFit();
        _ui.ActiveView.RefreshView();
    }

    private int AddPoint(Point3F p, Point3FArray points, Dictionary<Point3F, int> indexMap)
    {
        int index;
        if (!indexMap.TryGetValue(p, out index))
        {
            index = points.Count;
            points.Add(p);
            indexMap[p] = index;
        }
        return index;
    }
    private List<List<Point3F>> SimplifyAll(List<List<Point3F>> curves)
    {
        var result = new List<List<Point3F>>();
        foreach (var curve in curves)
            result.Add(PolylineSimplifier.SimplifyDouglasPeucker(curve, 0.001));
        return result;
    }

    private string CreateUniqueLayer(string baseName)
    {
        int index = 1;
        string layerName;
        var cadFile = _ui.ActiveView.CADFile;

        do
        {
            layerName = $"{baseName}{index:D4}";
            index++;
        }
        while (cadFile.HasLayer(layerName));

        cadFile.CreateLayer(layerName);
        cadFile.SetActiveLayer(layerName);
        return layerName;
    }
}